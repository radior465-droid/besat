# FM-DX Android Universal 0.75.0 — Adaptador IT9175

## Implementado
- Adaptador de identificação dedicado ao perfil ITE/Afatech IT9175 / PT275, VID:PID `048D:275A`.
- Enumeração observacional de interfaces e endpoints USB, incluindo índice da interface, endereço, direção, tipo de transferência e tamanho máximo de pacote.
- Estados explícitos: dispositivo não correspondente, identificado, permissão necessária e protocolo não implementado.
- Relatório do adaptador integrado ao diagnóstico USB já existente.
- Inicialização falha de forma segura com `UnsupportedOperationException`: nenhum comando experimental é enviado ao dongle.
- Versão Android atualizada para `versionCode 52` e `versionName 0.75.0`.

## Base técnica e limites
O projeto público OpenDTV documenta Mygica PadTV PT275, GMA Now e IT9175 associados ao USB ID `048d:275a`, com suporte confirmado em hardware para PT275 e uso de USB Host/OTG. O README também informa que a lógica do tuner foi desenvolvida por análise independente, não incorporando código/dados dos drivers proprietários. Esta versão do FM-DX usa essa referência apenas para orientar identificação e diagnóstico; não copia o driver OpenDTV nem implementa seu protocolo.

A enumeração de endpoints não identifica, por si só, qual endpoint carrega MPEG-TS. A permissão USB não significa que o firmware foi carregado, que o demodulador está inicializado ou que há sinal RF. Permanecem pendentes estudo e implementação verificável de firmware, comandos de inicialização, tuner/demodulador, sintonia ISDB-T e validação de PAT/PMT/fluxo real.

Referência: https://github.com/jpdcs/OpenDTV (README e licença MIT do projeto; consultado em 17/11/2026). A implementação FM-DX desta versão é independente.

## Validação
- Testes automatizados Node.js verificam a presença do perfil, os estados e a proteção contra inicialização não validada.
- Não foi executado build completo Gradle/APK neste ambiente.
- Não houve teste físico com dongle IT9175; o usuário não precisa adquirir hardware para esta etapa de desenvolvimento.
