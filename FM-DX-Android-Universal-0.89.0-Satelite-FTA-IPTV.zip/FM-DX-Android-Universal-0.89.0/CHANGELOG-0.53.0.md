# FM-DX Android Universal 0.53.0 — Identificação de programas MPEG-TS

## Novidades
- Parser de seção PAT: identifica programas e seus PIDs de PMT.
- Parser de seção PMT: identifica PID de PCR e fluxos elementares, incluindo seus stream types.
- Testes unitários para PAT, PMT, tabela inválida e seção truncada.
- Mantida a separação entre análise de fluxo e hardware de recepção.

## Limites técnicos
- O parser recebe seções PSI completas já extraídas; ainda não faz reassemblagem de seções entre pacotes TS.
- Não implementa sintonia ISDB-T, controle de demodulador, driver USB, decodificação de vídeo/áudio ou reprodução ao vivo.
- CRC é reservado no fim da seção, mas sua validação ainda não está implementada.

## Validação
- Inspeção estrutural do código e do ZIP.
- Testes unitários adicionados; executar `./gradlew test` e `./gradlew assembleDebug` com JDK 17 e Android SDK 35 para validação completa.
