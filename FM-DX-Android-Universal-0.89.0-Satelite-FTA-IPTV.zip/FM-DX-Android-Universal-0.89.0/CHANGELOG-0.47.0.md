# FM-DX Android Universal 0.47.0

## Laboratório Virtual de RF
- Adicionada tela acessível pela página inicial.
- Gerador de amostras I/Q sintéticas, com tons e ruído configuráveis no motor.
- FFT radix-2 com janela Hann, espectro deslocado e detecção de picos locais.
- Resultados exibidos em frequência absoluta virtual e dBFS.
- Documentados os limites: simulação não equivale a recepção ou medição real.

## Compatibilidade e validação
- Preservada a base de código fornecida na versão 0.43.0.
- Android `versionCode` 29 e `versionName` 0.47.0.
- Compilação completa ainda precisa ser executada no Android Studio com JDK 17 e SDK 35.
