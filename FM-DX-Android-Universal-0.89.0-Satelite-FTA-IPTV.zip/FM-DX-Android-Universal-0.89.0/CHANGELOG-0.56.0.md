# FM-DX Android Universal 0.56.0 — HTTPS Radio & TV Playback

## Novidades
- Reprodução HLS com HLS.js em navegadores sem suporte HLS nativo.
- Reprodução MPEG-DASH com DASH.js.
- Mantida reprodução direta nativa de streams de áudio e vídeo.
- Destruição dos players anteriores ao iniciar nova análise ou limpar a interface, evitando sessões de reprodução duplicadas.
- Versão Android atualizada para 0.56.0 (versionCode 33).

## Compatibilidade e limites
- HLS.js e DASH.js são carregados de CDNs públicos; é necessária conexão à Internet para obter as bibliotecas.
- A reprodução depende de CORS, codecs, disponibilidade do manifesto/segmentos e permissões do servidor de origem.
- Alguns streams exigem cabeçalhos, cookies ou autenticação que o player não consegue fornecer.
- Não há quebra de DRM, interceptação TLS, bypass de autenticação ou captura de tráfego de outros aplicativos.
- A identificação de um formato não garante que o conteúdo seja decodificável pelo navegador/dispositivo.

## Testes
- Testes unitários existentes do analisador permanecem como base; testes de reprodução real exigem streams públicos autorizados e navegador compatível.
