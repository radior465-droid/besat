# FM-DX Android Universal 0.66.0 — Media Session e Continuidade

## Novidades
- Integração opcional com a API Media Session do navegador para publicar título, artista/grupo e estado de reprodução.
- Ações de mídia play, pause, stop, próximo e anterior quando o navegador/plataforma oferece esses controles.
- Atualização do estado da sessão ao iniciar, pausar ou parar áudio/vídeo.
- Persistência adicional do último canal durante `pagehide`.
- Ações indisponíveis ou não suportadas são ignoradas sem interromper a reprodução.

## Limitações importantes
A API Media Session não garante reprodução em segundo plano em todos os aparelhos. O Android WebView, políticas de economia de bateria, navegador, codecs, CORS e o servidor de origem podem suspender ou bloquear a mídia. Esta versão não implementa um serviço Android nativo de reprodução em primeiro plano; portanto, não promete áudio contínuo com o aplicativo encerrado.

## Android
- versionCode: 43
- versionName: 0.66.0
