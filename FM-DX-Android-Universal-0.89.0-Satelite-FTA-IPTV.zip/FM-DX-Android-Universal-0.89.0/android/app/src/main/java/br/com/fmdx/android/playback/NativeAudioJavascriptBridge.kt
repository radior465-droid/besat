package br.com.fmdx.android.playback

import android.content.Context
import android.content.Intent
import android.os.Build
import android.webkit.JavascriptInterface

/** Ponte mínima para enviar uma estação de rádio da biblioteca web ao player nativo. */
class NativeAudioJavascriptBridge(context: Context) {
    private val appContext = context.applicationContext

    @JavascriptInterface
    fun start(title: String?, url: String?, media: String?, format: String?, queueJson: String?): String {
        val normalized = StreamUrlValidator.normalize(url) ?: return "URL inválida: use HTTP ou HTTPS sem credenciais."
        val mediaFormat = format.orEmpty().trim().uppercase()
        if (!NativeAudioRequestValidator.isSupported(media, format)) {
            return if (mediaFormat in setOf("MPEG-TS", "M3U", "M3U8"))
                "Selecione uma estação/fluxo individual; playlists e MPEG-TS não são aceitos diretamente."
            else "O serviço nativo aceita áudio direto ou HLS/DASH identificado como rádio."
        }
        val intent = Intent(appContext, BackgroundAudioService::class.java).apply {
            action = BackgroundAudioService.ACTION_PLAY
            putExtra(BackgroundAudioService.EXTRA_URL, normalized)
            putExtra(BackgroundAudioService.EXTRA_TITLE, title?.trim()?.take(120)?.ifBlank { "Rádio FM-DX" } ?: "Rádio FM-DX")
            putExtra(BackgroundAudioService.EXTRA_QUEUE, queueJson?.take(256_000))
        }
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) appContext.startForegroundService(intent)
            else appContext.startService(intent)
            "Comando enviado ao serviço nativo. Confira a notificação do FM-DX."
        } catch (error: Exception) {
            "Não foi possível iniciar o áudio nativo: ${error.message ?: "erro do Android"}"
        }
    }

    @JavascriptInterface fun pause(): String = send(BackgroundAudioService.ACTION_PAUSE)
    @JavascriptInterface fun next(): String = send(BackgroundAudioService.ACTION_NEXT)
    @JavascriptInterface fun previous(): String = send(BackgroundAudioService.ACTION_PREVIOUS)
    @JavascriptInterface fun resume(): String = send(BackgroundAudioService.ACTION_RESUME)
    @JavascriptInterface fun stop(): String = send(BackgroundAudioService.ACTION_STOP)

    private fun send(action: String): String = try {
        appContext.startService(Intent(appContext, BackgroundAudioService::class.java).setAction(action))
        "Comando enviado ao serviço nativo."
    } catch (error: Exception) {
        "Não foi possível enviar o comando: ${error.message ?: "erro do Android"}"
    }
}
