package br.com.fmdx.android.fm

/** Resultado explícito da detecção; evita confundir fabricante/chipset com suporte funcional. */
data class FmBackendStatus(
    val backendName: String,
    val detectedPlatform: Boolean,
    val controlAvailable: Boolean,
    val message: String
)
