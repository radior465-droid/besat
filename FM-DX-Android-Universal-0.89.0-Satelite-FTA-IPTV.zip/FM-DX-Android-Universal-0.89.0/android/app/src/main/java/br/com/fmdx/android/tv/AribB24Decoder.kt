package br.com.fmdx.android.tv

import java.nio.charset.Charset

/**
 * Conservative ARIB STD-B24 decoder for common SI/EPG text.
 * Supports ISO-2022 designation/invocation for Kanji (EUC-JP mapping),
 * alphanumeric, hiragana and katakana sets. DRCS, mosaics, macros,
 * proportional variants and broadcast display-control semantics are not rendered.
 */
class AribB24Decoder {
    private enum class SetKind(val twoByte: Boolean) { KANJI(true), ALNUM(false), HIRAGANA(false), KATAKANA(false), JIS_KATAKANA(false), UNSUPPORTED(false) }
    private data class GraphicSet(val kind: SetKind)

    private val eucJp: Charset? = try { Charset.forName("EUC-JP") } catch (_: Exception) { null }
    private val jisKatakana: Charset? = try { Charset.forName("EUC-JP") } catch (_: Exception) { null }

    fun decode(data: ByteArray, offset: Int = 0, length: Int = data.size - offset): String {
        if (offset < 0 || length < 0 || offset > data.size || length > data.size - offset) return ""
        val end = offset + length
        val sets = arrayOf(GraphicSet(SetKind.KANJI), GraphicSet(SetKind.ALNUM), GraphicSet(SetKind.HIRAGANA), GraphicSet(SetKind.UNSUPPORTED))
        var gl = 0
        var gr = 2
        var singleShift = -1
        val out = StringBuilder()
        var p = offset
        while (p < end) {
            val raw = data[p].toInt() and 0xff
            if (raw == 0x1b) {
                val parsed = parseEscape(data, p, end, sets)
                if (parsed > p) p = parsed else p++
                continue
            }
            when (raw) {
                0x0f -> { gl = 0; p++; continue }
                0x0e -> { gl = 1; p++; continue }
                0x6e -> { gl = 2; p++; continue }
                0x6f -> { gl = 3; p++; continue }
                0x7e -> { gr = 1; p++; continue }
                0x7d -> { gr = 2; p++; continue }
                0x7c -> { gr = 3; p++; continue }
                0x19 -> { singleShift = 2; p++; continue }
                0x1d -> { singleShift = 3; p++; continue }
            }
            val isGr = raw >= 0xa1
            val code = if (isGr) raw - 0x80 else raw
            if (code < 0x21 || code > 0x7e) { p++; continue }
            val setIndex = singleShift.takeIf { it >= 0 } ?: if (isGr) gr else gl
            singleShift = -1
            val set = sets[setIndex]
            if (set.kind.twoByte) {
                if (p + 1 >= end) break
                val raw2 = data[p + 1].toInt() and 0xff
                val code2 = if (raw2 >= 0xa1) raw2 - 0x80 else raw2
                if (code2 !in 0x21..0x7e) { p++; continue }
                appendJis(out, code, code2)
                p += 2
            } else {
                appendSingle(out, set.kind, code)
                p++
            }
        }
        return out.toString().trim('\u0000', ' ', '\u3000')
    }

    private fun parseEscape(data: ByteArray, start: Int, end: Int, sets: Array<GraphicSet>): Int {
        var p = start + 1
        if (p >= end) return start
        var twoByte = false
        if ((data[p].toInt() and 0xff) == 0x24) { twoByte = true; p++ }
        if (p >= end) return start
        val selector = data[p].toInt() and 0xff
        val target = if (selector in 0x28..0x2b) selector - 0x28 else 0
        if (selector in 0x28..0x2b) p++
        if (p >= end) return start
        val final = data[p].toInt() and 0xff
        sets[target] = GraphicSet(classify(final, twoByte))
        return p + 1
    }

    private fun classify(final: Int, twoByte: Boolean): SetKind {
        if (twoByte) return if (final == 0x42 || final == 0x40) SetKind.KANJI else SetKind.UNSUPPORTED
        return when (final) {
            0x4a, 0x36 -> SetKind.ALNUM
            0x30, 0x37 -> SetKind.HIRAGANA
            0x31, 0x38 -> SetKind.KATAKANA
            0x49 -> SetKind.JIS_KATAKANA
            else -> SetKind.UNSUPPORTED
        }
    }

    private fun appendSingle(out: StringBuilder, kind: SetKind, code: Int) {
        when (kind) {
            SetKind.ALNUM -> out.append(when (code) { 0x5c -> '\u00a5'; 0x7e -> '\u203e'; else -> code.toChar() })
            SetKind.HIRAGANA -> appendJis(out, 0x24, code)
            SetKind.KATAKANA -> appendJis(out, 0x25, code)
            SetKind.JIS_KATAKANA -> {
                val half = code - 0x21 + 0xa1
                val charset = jisKatakana
                if (charset == null) out.append('\ufffd')
                else try { out.append(charset.decode(java.nio.ByteBuffer.wrap(byteArrayOf(0x8e.toByte(), half.toByte())))) }
                catch (_: Exception) { out.append('\ufffd') }
            }
            else -> Unit
        }
    }

    private fun appendJis(out: StringBuilder, row: Int, cell: Int) {
        val charset = eucJp ?: run { out.append('\ufffd'); return }
        try {
            val bytes = byteArrayOf((row + 0x80).toByte(), (cell + 0x80).toByte())
            out.append(charset.decode(java.nio.ByteBuffer.wrap(bytes)))
        } catch (_: Exception) { out.append('\ufffd') }
    }
}
