package br.com.fmdx.android.fm.database

import android.content.Context
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * Catálogo conservador de assinaturas de plataforma. As entradas identificam
 * famílias de SoC/fabricante, nunca afirmam presença ou acesso a tuner FM.
 * Resultados de teste ficam vinculados ao fingerprint exato do firmware.
 */
class HardwareSignatureDatabase(context: Context) {
    private val prefs = context.getSharedPreferences("fmdx_signature_database", Context.MODE_PRIVATE)
    private val recordsKey = "device_observations"

    data class Match(val family: String, val evidence: String, val confidence: String, val fmMeaning: String)
    data class DeviceObservation(
        val fingerprint: String, val manufacturer: String, val model: String,
        val socManufacturer: String, val socModel: String, val androidRelease: String,
        val result: String, val testedAt: Long, val origin: String = "LOCAL"
    )

    // Only vendor/family identification aliases. These are not FM capability profiles.
    private val platformAliases = listOf(
        Triple("Qualcomm", listOf("qualcomm", "qcom", "snapdragon"), "Família de plataforma identificada; tuner/driver FM não inferidos."),
        Triple("MediaTek", listOf("mediatek", "mtk", "dimensity", "helio"), "Família de plataforma identificada; tuner/driver FM não inferidos."),
        Triple("Samsung Exynos", listOf("samsung", "exynos"), "Indício de plataforma Samsung; confirmar SoC e variante exatos."),
        Triple("Unisoc", listOf("unisoc", "spreadtrum", "ums"), "Família de plataforma identificada; tuner/driver FM não inferidos."),
        Triple("HiSilicon Kirin", listOf("hisilicon", "kirin"), "Família de plataforma identificada; tuner/driver FM não inferidos."),
        Triple("Google Tensor", listOf("google tensor", "tensor"), "Família de plataforma identificada; tuner/driver FM não inferidos.")
    )

    fun identifyPlatform(socManufacturer: String, socModel: String, hardware: String): Match {
        val source = listOf(socManufacturer, socModel, hardware).filter { it.isNotBlank() }
            .joinToString(" ").lowercase(Locale.ROOT)
        val match = platformAliases.firstOrNull { (_, aliases, _) -> aliases.any(source::contains) }
        return if (match != null) Match(match.first, "Build.SOC_MANUFACTURER/SOC_MODEL/HARDWARE", "INDÍCIO", match.third)
        else Match("Não identificado", "Campos públicos do Build", "DESCONHECIDO", "Nenhuma conclusão sobre FM pode ser feita.")
    }

    fun saveObservation(result: String) {
        val current = observations().filterNot { it.fingerprint == Build.FINGERPRINT } + DeviceObservation(
            fingerprint = Build.FINGERPRINT,
            manufacturer = Build.MANUFACTURER.orEmpty(),
            model = Build.MODEL.orEmpty(),
            socManufacturer = if (Build.VERSION.SDK_INT >= 31) Build.SOC_MANUFACTURER.orEmpty() else "API < 31",
            socModel = if (Build.VERSION.SDK_INT >= 31) Build.SOC_MODEL.orEmpty() else "API < 31",
            androidRelease = Build.VERSION.RELEASE.orEmpty(),
            result = result,
            testedAt = System.currentTimeMillis()
        )
        val array = JSONArray()
        current.takeLast(100).forEach { item -> array.put(JSONObject().apply {
            put("fingerprint", item.fingerprint); put("manufacturer", item.manufacturer)
            put("model", item.model); put("socManufacturer", item.socManufacturer)
            put("socModel", item.socModel); put("androidRelease", item.androidRelease)
            put("result", item.result); put("testedAt", item.testedAt); put("origin", item.origin)
        }) }
        prefs.edit().putString(recordsKey, array.toString()).apply()
    }

    fun observations(): List<DeviceObservation> = runCatching {
        val array = JSONArray(prefs.getString(recordsKey, "[]"))
        (0 until array.length()).map { i -> array.getJSONObject(i).let { o ->
            DeviceObservation(o.optString("fingerprint"), o.optString("manufacturer"),
                o.optString("model"), o.optString("socManufacturer"), o.optString("socModel"),
                o.optString("androidRelease"), o.optString("result"), o.optLong("testedAt"), o.optString("origin", "LOCAL"))
        } }
    }.getOrDefault(emptyList())


    /**
     * Compara observações locais sem transformar semelhança de SoC em prova de FM.
     * Agrupa apenas quando os campos públicos indicam a mesma família; modelos vazios
     * permanecem em "Plataforma não identificada".
     */
    fun comparisonSummary(): String {
        val items = observations()
        if (items.isEmpty()) return "Ainda não há observações salvas para comparar. Execute o Hardware Test Lab em um ou mais aparelhos."
        val cohorts = CrossDeviceCohortAnalyzer.analyze(items) { item ->
            identifyPlatform(item.socManufacturer, item.socModel, "").family
        }
        return buildString {
            append("Comparação local de ${items.size} observação(ões) em ${cohorts.size} grupo(s):\n")
            cohorts.forEach { cohort ->
                append("• ${cohort.platformFamily}: ${cohort.observationCount} teste(s), ${cohort.distinctFirmwareCount} fingerprint(s), ${cohort.distinctModels.size} modelo(s).\n")
                if (cohort.distinctModels.isNotEmpty()) append("  Modelos: ${cohort.distinctModels.take(8).joinToString(", ")}${if (cohort.distinctModels.size > 8) ", ..." else ""}\n")
                if (cohort.distinctSocModels.isNotEmpty()) append("  SoC exposto pelo Android: ${cohort.distinctSocModels.take(6).joinToString(", ")}\n")
                append("  Resultado FM não comprovado: ${cohort.fmUnconfirmedCount}/${cohort.observationCount}.\n")
                append("  Interpretação: ${cohort.interpretation}\n")
            }
            append("\nLIMITES DA COMPARAÇÃO\n")
            append("Os grupos são formados por campos públicos disponíveis e observações locais deste aparelho. Eles não demonstram que dois modelos compartilham tuner, cristal, driver, HAL ou funcionamento FM. Os dados não são enviados para um servidor nem combinados com testes de outros usuários.")
        }
    }

    /** Exporta somente campos técnicos selecionados. O fingerprint exclusivo do aparelho nunca sai do dispositivo. */
    fun exportCommunityReport(): String {
        val records = observations().takeLast(100)
        val payload = JSONArray()
        records.forEach { item ->
            payload.put(JSONObject().apply {
                put("manufacturer", item.manufacturer.take(80))
                put("model", item.model.take(100))
                put("socManufacturer", item.socManufacturer.take(80))
                put("socModel", item.socModel.take(100))
                put("androidRelease", item.androidRelease.take(30))
                put("result", normalizeCommunityResult(item.result))
                put("testedAtDay", java.text.SimpleDateFormat("yyyy-MM-dd", Locale.US).format(java.util.Date(item.testedAt)))
                put("origin", item.origin.take(20))
            })
        }
        return JSONObject().apply {
            put("format", "fmdx-community-compatibility")
            put("schemaVersion", 1)
            put("createdAt", System.currentTimeMillis())
            put("observations", payload)
            put("privacy", "No unique build fingerprint, serial number, account identifier or precise location is included.")
        }.toString(2)
    }

    /** Importação local, iniciada pelo usuário. Não acessa rede e limita tamanho/campos. */
    fun importCommunityReport(json: String): Int {
        require(json.length <= 512_000) { "Arquivo muito grande (limite de 512 KB)." }
        val root = JSONObject(json)
        require(root.optString("format") == "fmdx-community-compatibility") { "Formato de relatório não reconhecido." }
        require(root.optInt("schemaVersion") == 1) { "Versão do relatório não suportada." }
        val array = root.optJSONArray("observations") ?: throw IllegalArgumentException("Relatório sem observações.")
        require(array.length() in 1..100) { "O relatório deve conter de 1 a 100 observações." }
        val existing = observations().toMutableList()
        var added = 0
        for (i in 0 until array.length()) {
            val o = array.optJSONObject(i) ?: continue
            val manufacturer = o.optString("manufacturer").take(80)
            val model = o.optString("model").take(100)
            val socManufacturer = o.optString("socManufacturer").take(80)
            val socModel = o.optString("socModel").take(100)
            val androidRelease = o.optString("androidRelease").take(30)
            val result = normalizeCommunityResult(o.optString("result"))
            val day = o.optString("testedAtDay").take(10)
            require(manufacturer.isNotBlank() || model.isNotBlank() || socManufacturer.isNotBlank() || socModel.isNotBlank()) { "Observação ${i + 1} sem identificação técnica mínima." }
            val stable = listOf(manufacturer, model, socManufacturer, socModel, androidRelease, result, day).joinToString("|")
            val digest = java.security.MessageDigest.getInstance("SHA-256").digest(stable.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
            val syntheticFingerprint = "community:$digest"
            if (existing.none { it.fingerprint == syntheticFingerprint }) {
                val timestamp = runCatching { java.text.SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(day)?.time }.getOrNull() ?: 0L
                existing.add(DeviceObservation(syntheticFingerprint, manufacturer, model, socManufacturer, socModel, androidRelease, result, timestamp, "COMUNITÁRIO"))
                added++
            }
        }
        val out = JSONArray()
        existing.takeLast(100).forEach { item -> out.put(JSONObject().apply {
            put("fingerprint", item.fingerprint); put("manufacturer", item.manufacturer); put("model", item.model)
            put("socManufacturer", item.socManufacturer); put("socModel", item.socModel); put("androidRelease", item.androidRelease)
            put("result", item.result); put("testedAt", item.testedAt); put("origin", item.origin)
        }) }
        prefs.edit().putString(recordsKey, out.toString()).apply()
        return added
    }

    private fun normalizeCommunityResult(value: String): String = when {
        value.contains("COMPROVADO", true) -> "FM NÃO COMPROVADO"
        value.contains("UNKNOWN", true) -> "FM NÃO COMPROVADO"
        else -> "FM NÃO COMPROVADO"
    }

    fun exactFirmwareHistory(): List<DeviceObservation> = observations().filter { it.fingerprint == Build.FINGERPRINT }
}
