package br.com.fmdx.android.playback

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import android.os.Build
import android.os.IBinder
import android.util.Log
import br.com.fmdx.android.MainActivity
import org.json.JSONArray

/** Player nativo independente do WebView, com fila local e avanço automático. */
class BackgroundAudioService : Service() {
    private data class Station(val title: String, val url: String)

    private var player: ExoPlayer? = null
    private var title: String = "Rádio FM-DX"
    private var streamUrl: String? = null
    private var prepared = false
    private var queue: List<Station> = emptyList()
    private var queueIndex = -1

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PLAY -> {
                val valid = StreamUrlValidator.normalize(intent.getStringExtra(EXTRA_URL))
                if (valid == null) {
                    stopSelf(startId)
                    return START_NOT_STICKY
                }
                title = intent.getStringExtra(EXTRA_TITLE)?.take(120)?.ifBlank { "Rádio FM-DX" } ?: "Rádio FM-DX"
                queue = parseQueue(intent.getStringExtra(EXTRA_QUEUE))
                queueIndex = queue.indexOfFirst { it.url == valid }
                if (queueIndex < 0) {
                    queue = listOf(Station(title, valid)) + queue
                    queueIndex = 0
                }
                startForeground(NOTIFICATION_ID, buildNotification("Conectando…", false))
                startStream(valid)
            }
            ACTION_PAUSE -> pausePlayback()
            ACTION_RESUME -> resumePlayback()
            ACTION_NEXT -> moveQueue(1)
            ACTION_PREVIOUS -> moveQueue(-1)
            ACTION_STOP -> { stopPlayback(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }
        }
        return START_NOT_STICKY
    }

    private fun parseQueue(raw: String?): List<Station> {
        if (raw.isNullOrBlank() || raw.length > 256_000) return emptyList()
        return try {
            val json = JSONArray(raw)
            buildList {
                for (i in 0 until minOf(json.length(), 100)) {
                    val item = json.optJSONObject(i) ?: continue
                    val url = StreamUrlValidator.normalize(item.optString("url")) ?: continue
                    val name = item.optString("title", "Rádio FM-DX").take(120).ifBlank { "Rádio FM-DX" }
                    if (none { it.url == url }) add(Station(name, url))
                }
            }
        } catch (_: Exception) { emptyList() }
    }

    private fun moveQueue(direction: Int) {
        if (queue.isEmpty() || queueIndex !in queue.indices) {
            updateNotification("Fila nativa vazia", false)
            return
        }
        val next = queueIndex + direction
        if (next !in queue.indices) {
            updateNotification(if (direction > 0) "Fim da fila" else "Início da fila", false)
            return
        }
        queueIndex = next
        val station = queue[queueIndex]
        title = station.title
        startStream(station.url)
    }

    private fun startStream(url: String) {
        stopPlayback()
        streamUrl = url
        try {
            val exo = ExoPlayer.Builder(this).build()
            player = exo
            exo.addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(playbackState: Int) {
                    when (playbackState) {
                        Player.STATE_BUFFERING -> updateNotification("Conectando…", false)
                        Player.STATE_READY -> {
                            prepared = true
                            updateNotification(if (exo.playWhenReady) "Reproduzindo" else "Pronto", exo.isPlaying)
                        }
                        Player.STATE_ENDED -> {
                            if (queueIndex in queue.indices && queueIndex + 1 < queue.size) moveQueue(1)
                            else updateNotification("Transmissão encerrada", false)
                        }
                    }
                }

                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    updateNotification(if (isPlaying) "Reproduzindo" else "Pausado", isPlaying)
                }

                override fun onPlayerError(error: PlaybackException) {
                    Log.w(TAG, "Falha no fluxo nativo: ${error.errorCodeName}", error)
                    updateNotification("Falha: ${error.errorCodeName}", false)
                }
            })
            exo.setMediaItem(MediaItem.fromUri(url))
            exo.prepare()
            exo.playWhenReady = true
        } catch (e: Exception) { fail(e) }
    }

    private fun fail(error: Exception) {
        Log.w(TAG, "Falha ao iniciar fluxo de áudio", error)
        updateNotification("Falha na reprodução", false)
    }

    private fun pausePlayback() {
        try { player?.pause() } catch (_: Exception) { }
        updateNotification("Pausado", false)
    }

    private fun resumePlayback() {
        try {
            val media = player
            if (media != null) { media.play(); updateNotification("Reproduzindo", true) }
            else streamUrl?.let { startStream(it) }
        } catch (e: Exception) { fail(e) }
    }

    private fun stopPlayback() {
        prepared = false
        try { player?.stop(); player?.release() } catch (_: Exception) { }
        player = null
    }

    private fun serviceAction(action: String, requestCode: Int) = PendingIntent.getService(
        this, requestCode, Intent(this, BackgroundAudioService::class.java).setAction(action), pendingFlags())

    private fun buildNotification(status: String, playing: Boolean): Notification {
        val open = PendingIntent.getActivity(this, 10, Intent(this, MainActivity::class.java), pendingFlags())
        val toggleAction = if (playing) ACTION_PAUSE else ACTION_RESUME
        val toggleLabel = if (playing) "Pausar" else "Retomar"
        val toggleIcon = if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
        @Suppress("DEPRECATION")
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        builder.setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(title).setContentText(status).setContentIntent(open)
            .setOngoing(playing || status == "Conectando…")
            .setCategory(Notification.CATEGORY_TRANSPORT)
            .addAction(android.R.drawable.ic_media_previous, "Anterior", serviceAction(ACTION_PREVIOUS, 13))
            .addAction(toggleIcon, toggleLabel, serviceAction(toggleAction, 11))
            .addAction(android.R.drawable.ic_media_next, "Próxima", serviceAction(ACTION_NEXT, 14))
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Parar", serviceAction(ACTION_STOP, 12))
        return builder.build()
    }

    private fun updateNotification(status: String, playing: Boolean) {
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIFICATION_ID, buildNotification(status, playing))
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Reprodução em segundo plano", NotificationManager.IMPORTANCE_LOW)
            channel.description = "Controles do áudio reproduzido pelo FM-DX"
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun pendingFlags(): Int = PendingIntent.FLAG_UPDATE_CURRENT or
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0

    override fun onTaskRemoved(rootIntent: Intent?) { super.onTaskRemoved(rootIntent) }
    override fun onDestroy() { stopPlayback(); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_PLAY = "br.com.fmdx.action.PLAY"
        const val ACTION_PAUSE = "br.com.fmdx.action.PAUSE"
        const val ACTION_RESUME = "br.com.fmdx.action.RESUME"
        const val ACTION_NEXT = "br.com.fmdx.action.NEXT"
        const val ACTION_PREVIOUS = "br.com.fmdx.action.PREVIOUS"
        const val ACTION_STOP = "br.com.fmdx.action.STOP"
        const val EXTRA_URL = "stream_url"
        const val EXTRA_TITLE = "stream_title"
        const val EXTRA_QUEUE = "stream_queue"
        private const val TAG = "FMDXPlayback"
        private const val CHANNEL_ID = "fmdx_background_audio"
        private const val NOTIFICATION_ID = 6701
    }
}
