package br.com.fmdx.android.fm

import android.os.Build

/** Perfil baseado em campos públicos do Android. Marca/modelo não são prova de SoC. */
data class DeviceProfile(
    val platform: String,
    val backendId: String,
    val confidence: String,
    val evidence: List<String>,
    val manufacturer: String,
    val model: String,
    val hardware: String,
    val board: String,
    val device: String,
    val product: String,
    val socManufacturer: String,
    val socModel: String
) {
    fun summary(): String = "$platform ($confidence)"
}

object DeviceProfileDetector {
    fun detect(): DeviceProfile {
        val manufacturer = Build.MANUFACTURER.orEmpty()
        val model = Build.MODEL.orEmpty()
        val hardware = Build.HARDWARE.orEmpty()
        val board = Build.BOARD.orEmpty()
        val device = Build.DEVICE.orEmpty()
        val product = Build.PRODUCT.orEmpty()
        val socManufacturer = if (Build.VERSION.SDK_INT >= 31) Build.SOC_MANUFACTURER.orEmpty() else ""
        val socModel = if (Build.VERSION.SDK_INT >= 31) Build.SOC_MODEL.orEmpty() else ""

        // Campos dedicados ao SoC têm prioridade e são identificados separadamente.
        val direct = "$socManufacturer $socModel".lowercase()
        val platformText = listOf(hardware, board, device, product).joinToString(" ").lowercase()
        fun matches(text: String, keys: List<String>) = keys.filter { text.contains(it) }
        val families = listOf(
            Triple("Qualcomm/Snapdragon", "qualcomm", listOf("qualcomm", "qcom", "snapdragon", "sdm", "sm6", "sm7", "sm8")),
            Triple("MediaTek", "mediatek", listOf("mediatek", "mt67", "mt68", "mt69", "dimensity", "helio")),
            Triple("Samsung Exynos", "samsung_exynos", listOf("exynos", "s5e")),
            Triple("Unisoc", "unisoc", listOf("unisoc", "spreadtrum", "ums")),
            Triple("HiSilicon/Kirin", "hisilicon", listOf("kirin", "hisilicon", "hi36")),
            Triple("Google Tensor", "google_tensor", listOf("tensor", "gs101", "gs201", "gs3"))
        )
        val directHit = families.firstOrNull { matches(direct, it.third).isNotEmpty() }
        val platformHit = families.firstOrNull { matches(platformText, it.third).isNotEmpty() }
        val selected = directHit ?: platformHit
        val evidence = mutableListOf<String>()
        if (socManufacturer.isNotBlank() || socModel.isNotBlank()) {
            evidence += "Campos públicos do SoC: fabricante='${socManufacturer.ifBlank { "não informado" }}', modelo='${socModel.ifBlank { "não informado" }}'"
        }
        if (selected != null) {
            val source = if (directHit != null) "campos dedicados do SoC" else "hardware/board/device/product"
            evidence += "Assinatura ${selected.first} encontrada em $source"
        } else {
            evidence += "Nenhuma assinatura pública confiável de plataforma encontrada"
        }
        val brandHint = listOf(manufacturer, Build.BRAND.orEmpty()).joinToString(" ").lowercase()
        val genericSamsung = selected == null && brandHint.contains("samsung")
        val platform = selected?.first ?: if (genericSamsung) "Samsung (SoC não confirmado)" else "Desconhecida"
        val backend = selected?.second ?: if (genericSamsung) "samsung_generic" else "unknown"
        val confidence = when {
            directHit != null -> "alta (campo SoC informado pelo sistema)"
            platformHit != null -> "média (assinatura de hardware; requer confirmação)"
            else -> "baixa / não identificada"
        }
        return DeviceProfile(platform, backend, confidence, evidence, manufacturer, model, hardware, board, device, product, socManufacturer, socModel)
    }
}
