package br.com.fmdx.android.tv

import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice

/** Estados observáveis do adaptador; identificação nunca equivale a recepção de TV. */
enum class It9175ProbeState {
    NOT_MATCHED,
    IDENTIFIED,
    USB_PERMISSION_REQUIRED,
    USB_PERMISSION_GRANTED,
    INTERFACES_ENUMERATED,
    PROTOCOL_NOT_IMPLEMENTED,
    STREAM_NOT_VERIFIED
}

data class It9175EndpointEvidence(
    val interfaceIndex: Int,
    val endpointAddress: Int,
    val direction: String,
    val transferType: String,
    val maxPacketSize: Int
)

data class It9175ProbeReport(
    val matched: Boolean,
    val state: It9175ProbeState,
    val stages: List<It9175ProbeState>,
    val usbId: String,
    val interfaceCount: Int,
    val endpoints: List<It9175EndpointEvidence>,
    val messages: List<String>
)

/**
 * Adaptador de identificação/descritores para ITE IT9175 (048d:275a).
 * Não envia transferências vendor-specific, não carrega firmware e não sintoniza RF.
 * A implementação do protocolo deve ser baseada em especificação/licença verificável
 * e validada com hardware antes de habilitar qualquer comando de escrita.
 */
object It9175Adapter {
    const val VENDOR_ID = 0x048d
    const val PRODUCT_ID = 0x275a

    fun probe(device: UsbDevice, hasPermission: Boolean): It9175ProbeReport {
        val matched = device.vendorId == VENDOR_ID && device.productId == PRODUCT_ID
        val usbId = "%04X:%04X".format(device.vendorId, device.productId)
        if (!matched) return It9175ProbeReport(
            false, It9175ProbeState.NOT_MATCHED, listOf(It9175ProbeState.NOT_MATCHED), usbId, device.interfaceCount,
            emptyList(), listOf("VID/PID não corresponde ao perfil IT9175 048D:275A.")
        )

        val endpoints = buildList {
            for (interfaceIndex in 0 until device.interfaceCount) {
                val intf = device.getInterface(interfaceIndex)
                for (endpointIndex in 0 until intf.endpointCount) {
                    val endpoint = intf.getEndpoint(endpointIndex)
                    add(It9175EndpointEvidence(
                        interfaceIndex = interfaceIndex,
                        endpointAddress = endpoint.address,
                        direction = if (endpoint.direction == UsbConstants.USB_DIR_IN) "IN" else "OUT",
                        transferType = when (endpoint.type) {
                            UsbConstants.USB_ENDPOINT_XFER_BULK -> "BULK"
                            UsbConstants.USB_ENDPOINT_XFER_INT -> "INTERRUPT"
                            UsbConstants.USB_ENDPOINT_XFER_ISOC -> "ISOCHRONOUS"
                            UsbConstants.USB_ENDPOINT_XFER_CONTROL -> "CONTROL"
                            else -> "UNKNOWN"
                        },
                        maxPacketSize = endpoint.maxPacketSize
                    ))
                }
            }
        }
        val stages = buildList {
            add(It9175ProbeState.IDENTIFIED)
            add(if (hasPermission) It9175ProbeState.USB_PERMISSION_GRANTED else It9175ProbeState.USB_PERMISSION_REQUIRED)
            add(It9175ProbeState.INTERFACES_ENUMERATED)
            add(It9175ProbeState.PROTOCOL_NOT_IMPLEMENTED)
            add(It9175ProbeState.STREAM_NOT_VERIFIED)
        }
        val state = stages.last()
        val messages = mutableListOf(
            "Família IT9175/PT275 identificada pelo VID/PID 048D:275A; revisão exata da placa não confirmada.",
            "Descritores enumerados: ${device.interfaceCount} interface(s), ${endpoints.size} endpoint(s).",
            "A existência de endpoint BULK-IN não prova que ele transporte MPEG-TS."
        )
        if (!hasPermission) messages += "Solicite a permissão USB pelo Android antes de qualquer comunicação."
        else messages += "Permissão USB concedida; protocolo de inicialização/firmware ainda não implementado neste adaptador."
        messages += "Sintonia RF e fluxo MPEG-TS permanecem não verificados."
        return It9175ProbeReport(true, state, stages, usbId, device.interfaceCount, endpoints, messages)
    }

    /** Falha fechada: evita transmitir comandos ainda não verificados ao hardware. */
    fun initialize(): Nothing = throw UnsupportedOperationException(
        "Inicialização IT9175 indisponível: sequência de protocolo/firmware ainda não validada."
    )
}
