package br.com.fmdx.android.media.intelligence

import br.com.fmdx.android.media.MediaDecision
import br.com.fmdx.android.media.MediaKind
import br.com.fmdx.android.media.SmartMediaEngine

enum class SupportState { DETECTED, SUPPORTED, DRIVER_REQUIRED, UNKNOWN }

data class SourceInsight(
    val decision: MediaDecision,
    val category: String,
    val support: SupportState,
    val diagnostic: String
)

/**
 * 0.27.0 discovery layer. It classifies evidence only and never claims
 * hardware control unless a real backend/driver reports it.
 */
object UniversalMediaIntelligence {
    fun inspect(source: String): SourceInsight {
        val decision = SmartMediaEngine.classify(source)
        return when (decision.kind) {
            MediaKind.HLS -> SourceInsight(decision, "TV / vídeo streaming", SupportState.SUPPORTED,
                "HLS identificado pela URL; a reprodução depende do player configurado.")
            MediaKind.DASH -> SourceInsight(decision, "TV / vídeo streaming", SupportState.SUPPORTED,
                "DASH identificado pela URL; a reprodução depende do player configurado.")
            MediaKind.VIDEO_FILE -> SourceInsight(decision, "Arquivo de vídeo", SupportState.SUPPORTED,
                "Formato reconhecido; codec e reprodução precisam ser confirmados em tempo de execução.")
            MediaKind.FM_NATIVE -> SourceInsight(decision, "Rádio FM", SupportState.DRIVER_REQUIRED,
                "FM nativo exige backend e permissões realmente disponíveis no dispositivo.")
            MediaKind.WEB -> SourceInsight(decision, "Fonte web", SupportState.UNKNOWN,
                "URL detectada, mas o tipo de mídia ainda precisa ser confirmado.")
            MediaKind.UNKNOWN -> SourceInsight(decision, "Desconhecido", SupportState.UNKNOWN,
                "Nenhum perfil confiável foi encontrado para esta fonte.")
        }
    }
}
