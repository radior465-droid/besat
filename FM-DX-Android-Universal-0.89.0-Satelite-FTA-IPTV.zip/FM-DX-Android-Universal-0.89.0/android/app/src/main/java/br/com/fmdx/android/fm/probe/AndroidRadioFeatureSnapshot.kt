package br.com.fmdx.android.fm.probe

import android.content.Context
import android.os.Build

/** Registra somente recursos declarados pelo Android; não prova tuner FM nem acesso ao driver. */
object AndroidRadioFeatureSnapshot {
    fun collect(context: Context): List<String> {
        val pm = context.packageManager
        val candidates = pm.systemAvailableFeatures.orEmpty()
            .mapNotNull { it.name }
            .filter { name ->
                val value = name.lowercase()
                value.contains("radio") || value.contains("fm") || value.contains("tuner") || value.contains("telephony")
            }
            .distinct()
            .sorted()
        val result = mutableListOf<String>()
        result += "Versão Android/API: ${Build.VERSION.RELEASE} / ${Build.VERSION.SDK_INT}"
        result += "Patch de segurança: ${Build.VERSION.SECURITY_PATCH.ifBlank { "não informado" }}"
        if (candidates.isEmpty()) {
            result += "PackageManager não declarou recursos com nomes relacionados a rádio/FM/tuner/telefonia"
        } else {
            result += "Recursos declarados pelo sistema (não equivalem a tuner FM comprovado): ${candidates.joinToString() }"
        }
        return result
    }
}
