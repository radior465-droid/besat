package br.com.fmdx.android.media.receiver

enum class ReceiverMode { FM_NATIVE, VIRTUAL_RADIO, DSP, TV_VIDEO, UNKNOWN }
enum class CompatibilityState { DETECTED, SUPPORTED, DRIVER_REQUIRED, UNKNOWN }

data class ReceiverStatus(
    val mode: ReceiverMode,
    val compatibility: CompatibilityState,
    val detail: String
)

/**
 * Central model for the 0.29.0 receiver. It reports known state and does not
 * convert detection into a claim that a tuner can be controlled.
 */
object IntelligentReceiverCenter {
    fun describe(mode: ReceiverMode, compatibility: CompatibilityState): ReceiverStatus {
        val detail = when (compatibility) {
            CompatibilityState.SUPPORTED -> "Backend disponível para o perfil selecionado"
            CompatibilityState.DRIVER_REQUIRED -> "Dispositivo detectado; driver/backend ainda necessário"
            CompatibilityState.DETECTED -> "Hardware ou fonte detectada; controle não confirmado"
            CompatibilityState.UNKNOWN -> "Sem evidência suficiente para confirmar compatibilidade"
        }
        return ReceiverStatus(mode, compatibility, detail)
    }
}
