package br.com.fmdx.android.tv

/**
 * Reassembles PSI/SI sections from MPEG-TS packets for a single PID.
 * Handles payload offsets, adaptation fields, PUSI pointer_field, section
 * boundaries spanning packets, multiple sections per payload and continuity gaps.
 * This is a byte-level parser only: it does not tune RF or control a USB tuner.
 */
class PsiSectionAssembler(private val targetPid: Int) {
    private val pending = ArrayList<Byte>(1024)
    private var expectedSize: Int? = null
    private var lastContinuity: Int? = null

    init { require(targetPid in 0..0x1fff) { "PID fora do intervalo MPEG-TS" } }

    fun reset() {
        pending.clear()
        expectedSize = null
        lastContinuity = null
    }

    /** Feed exactly one 188-byte TS packet; returns complete PSI sections. */
    fun feed(packet: ByteArray): List<ByteArray> {
        if (packet.size != MpegTsAnalyzer.PACKET_SIZE) return emptyList()
        val parsed = MpegTsAnalyzer.parsePacket(packet) ?: return emptyList()
        if (parsed.pid != targetPid || parsed.transportError || parsed.scramblingControl != 0) return emptyList()
        if (parsed.adaptationFieldControl == 2) return emptyList()
        val hasPayload = parsed.adaptationFieldControl == 1 || parsed.adaptationFieldControl == 3
        if (!hasPayload) return emptyList()

        val previous = lastContinuity
        if (previous != null && parsed.continuityCounter != ((previous + 1) and 0x0f)) {
            pending.clear(); expectedSize = null
        }
        lastContinuity = parsed.continuityCounter

        var offset = 4
        if (parsed.adaptationFieldControl == 3) {
            val adaptationLength = packet[offset].toInt() and 0xff
            offset += 1 + adaptationLength
            if (offset > packet.size) { pending.clear(); expectedSize = null; return emptyList() }
        }
        if (offset >= packet.size) return emptyList()
        val output = mutableListOf<ByteArray>()
        if (parsed.payloadUnitStart) {
            val pointer = packet[offset].toInt() and 0xff
            offset++
            if (pointer > packet.size - offset) { pending.clear(); expectedSize = null; return emptyList() }
            if (pointer > 0 && pending.isNotEmpty()) append(packet, offset, offset + pointer, output)
            // A PUSI marks the beginning of a new section after pointer_field.
            if (pending.isNotEmpty()) { pending.clear(); expectedSize = null }
            offset += pointer
            append(packet, offset, packet.size, output, allowMultiple = true)
        } else if (pending.isNotEmpty()) {
            append(packet, offset, packet.size, output)
        }
        return output
    }

    private fun append(bytes: ByteArray, start: Int, end: Int, output: MutableList<ByteArray>, allowMultiple: Boolean = false) {
        var i = start
        while (i < end) {
            if (pending.isEmpty() && (bytes[i].toInt() and 0xff) == 0xff) return // stuffing
            val need = expectedSize
            val take = if (need == null) minOf(3 - pending.size, end - i) else minOf(need - pending.size, end - i)
            repeat(take) { pending.add(bytes[i++]) }
            if (expectedSize == null && pending.size == 3) {
                val sectionLength = ((pending[1].toInt() and 0x0f) shl 8) or (pending[2].toInt() and 0xff)
                if (sectionLength < 4 || sectionLength > 1021) { pending.clear(); return }
                expectedSize = 3 + sectionLength
            }
            val target = expectedSize
            if (target != null && pending.size == target) {
                output += pending.toByteArray()
                pending.clear(); expectedSize = null
                if (!allowMultiple) return
            }
        }
    }
}
