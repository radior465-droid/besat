package br.com.fmdx.android.video

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class VideoProfileStore(context: Context) {
    private val prefs = context.getSharedPreferences("fmdx_video", Context.MODE_PRIVATE)
    fun load(): List<VideoSource> = try {
        val arr = JSONArray(prefs.getString("sources", "[]"))
        (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            VideoSource(o.optString("url"), o.optString("label", "Fonte de vídeo"), runCatching { VideoSource.Type.valueOf(o.optString("type", "AUTO")) }.getOrDefault(VideoSource.Type.AUTO))
        }.filter { it.url.isNotBlank() }
    } catch (_: Exception) { emptyList() }
    fun save(source: VideoSource) {
        val all = load().filterNot { it.url == source.url }.toMutableList(); all.add(source)
        val arr = JSONArray(); all.forEach { s -> arr.put(JSONObject().put("url", s.url).put("label", s.label).put("type", s.type.name)) }
        prefs.edit().putString("sources", arr.toString()).apply()
    }
    fun remove(url: String) { prefs.edit().putString("sources", JSONArray(load().filterNot { it.url == url }.map { JSONObject().put("url",it.url).put("label",it.label).put("type",it.type.name) }).toString()).apply() }
}
