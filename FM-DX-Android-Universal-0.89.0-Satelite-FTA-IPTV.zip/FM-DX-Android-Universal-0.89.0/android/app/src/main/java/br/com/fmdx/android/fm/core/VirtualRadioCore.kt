package br.com.fmdx.android.fm.core

import br.com.fmdx.android.fm.profile.HardwareProfile

class VirtualRadioCore {
    fun evaluate(profile: HardwareProfile): CompatibilityDecision = DecisionEngine.decide(profile)
}
