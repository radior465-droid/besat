package br.com.fmdx.android.control

import android.content.Context
import br.com.fmdx.android.integration.IntegrationRegistry
import br.com.fmdx.android.integration.LiveStatusSnapshot
import br.com.fmdx.android.integration.TechnicalEventLog

/**
 * Consulta unificada para o painel em tempo real.
 * Os estados vêm de módulos/probes; esta classe não inventa suporte de hardware.
 */
object RealTimeControlCenter {
    fun snapshot(context: Context): ControlCenterState {
        IntegrationRegistry.seedDefaults()
        val caps = IntegrationRegistry.snapshot()
        val byId = caps.associateBy { it.id }
        val live = LiveStatusSnapshot(
            fm = byId["fm"]?.state?.name ?: "UNKNOWN",
            video = byId["video"]?.state?.name ?: "UNKNOWN",
            usb = byId["usb_tv"]?.state?.name ?: "UNKNOWN",
            diagnostics = "READY",
            intelligence = byId["media"]?.state?.name ?: "UNKNOWN"
        )
        val events = TechnicalEventLog(context).read().takeLast(12).asReversed().map {
            "[${it.level}] ${it.source}: ${it.message}"
        }
        return ControlCenterState(live, caps, events)
    }
}
