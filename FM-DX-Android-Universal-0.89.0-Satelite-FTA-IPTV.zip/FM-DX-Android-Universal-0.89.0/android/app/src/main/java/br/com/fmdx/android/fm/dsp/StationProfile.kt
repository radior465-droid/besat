package br.com.fmdx.android.fm.dsp

data class StationProfile(
    val frequencyKhz: Int,
    val label: String,
    val source: String,
    val confidence: Int,
    val notes: String
)
