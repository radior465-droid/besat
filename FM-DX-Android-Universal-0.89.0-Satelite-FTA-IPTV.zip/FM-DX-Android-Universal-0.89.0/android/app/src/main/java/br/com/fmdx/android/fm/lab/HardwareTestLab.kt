package br.com.fmdx.android.fm.lab

import android.content.Context
import android.content.pm.PackageManager
import android.hardware.usb.UsbManager
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import br.com.fmdx.android.fm.core.AdaptiveRadioDecisionEngine
import br.com.fmdx.android.fm.detector.UniversalHardwareDetector
import br.com.fmdx.android.fm.profile.BrandCompatibilityCatalog
import br.com.fmdx.android.fm.signature.SignatureGenerator
import br.com.fmdx.android.fm.database.HardwareSignatureDatabase
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Laboratório observacional. Não sintoniza, não abre interfaces privadas e não altera
 * configurações do sistema. Cada teste descreve somente o que o Android expõe ao app.
 */
class HardwareTestLab(private val context: Context) {
    private val prefs = context.getSharedPreferences("fmdx_hardware_lab", Context.MODE_PRIVATE)

    data class Result(val name: String, val status: String, val detail: String)

    fun run(): List<Result> {
        val app = context.applicationContext
        val pm = app.packageManager
        val profile = UniversalHardwareDetector(app).detect()
        val decision = AdaptiveRadioDecisionEngine.evaluate(profile)
        val signature = SignatureGenerator.generate(profile)
        val brand = BrandCompatibilityCatalog.identify()
        val signatureDb = HardwareSignatureDatabase(app)
        val socManufacturer = if (Build.VERSION.SDK_INT >= 31) Build.SOC_MANUFACTURER.orEmpty() else ""
        val socModel = if (Build.VERSION.SDK_INT >= 31) Build.SOC_MODEL.orEmpty() else ""
        val platformMatch = signatureDb.identifyPlatform(socManufacturer, socModel, Build.HARDWARE.orEmpty())

        val features = try {
            pm.systemAvailableFeatures.mapNotNull { it.name }
                .filter { it.contains("fm", true) || it.contains("radio", true) || it.contains("tuner", true) }
                .distinct().sorted()
        } catch (_: Exception) { emptyList() }

        val usbHost = try { pm.hasSystemFeature(PackageManager.FEATURE_USB_HOST) } catch (_: Exception) { false }
        val usbDevices = try {
            (app.getSystemService(Context.USB_SERVICE) as UsbManager).deviceList.values.toList()
        } catch (_: Exception) { emptyList() }

        val audioDevices = try {
            val audio = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            audio.getDevices(AudioManager.GET_DEVICES_ALL).toList()
        } catch (_: Exception) { emptyList() }
        val audioSummary = audioDevices.groupBy { it.type }.entries
            .sortedBy { it.key }
            .joinToString { (type, devices) -> "${audioTypeName(type)} x${devices.size}" }

        return listOf(
            Result("Identidade do aparelho", "COLETADO", "${Build.MANUFACTURER} / ${Build.BRAND} / ${Build.MODEL}; Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"),
            Result("Família de fabricante", "INFORMATIVO", "${brand.family}. ${brand.note}"),
            Result("Assinatura de plataforma", platformMatch.confidence,
                "${platformMatch.family}; fonte: ${platformMatch.evidence}. ${platformMatch.fmMeaning}"),
            Result("Identificação pública do SoC", if (socModel.isNotBlank() || socManufacturer.isNotBlank()) "OBSERVADO" else "LIMITADO",
                if (Build.VERSION.SDK_INT >= 31) "Fabricante: ${socManufacturer.ifBlank { "não exposto" }}; modelo: ${socModel.ifBlank { "não exposto" }}; hardware: ${Build.HARDWARE}." else "Android API ${Build.VERSION.SDK_INT} não expõe Build.SOC_MANUFACTURER/SOC_MODEL."),
            Result("Assinatura do hardware", "COLETADO", "Fingerprint: ${signature.key}"),
            Result("Plataforma / SoC", if (profile.evidence.isNotEmpty()) "INDÍCIO" else "NÃO IDENTIFICADO", "${profile.platform}; ${profile.evidence.size} evidência(s) observável(is). Isso não confirma tuner FM físico."),
            Result("Recursos de rádio declarados", if (features.isNotEmpty()) "OBSERVADO" else "NÃO DECLARADO", if (features.isEmpty()) "Nenhum recurso com nome FM/Radio/Tuner foi exposto pelo PackageManager." else features.joinToString("; ")), 
            Result("Áudio do sistema", if (audioDevices.isNotEmpty()) "OBSERVADO" else "SEM DADOS", audioSummary.ifBlank { "Nenhum dispositivo de áudio enumerado." } + ". A lista de áudio não identifica por si só o áudio interno do tuner."),
            Result("USB Host", if (usbHost) "DISPONÍVEL" else "NÃO DECLARADO", if (usbHost) "O Android declara suporte a USB Host." else "O Android não declara USB Host neste aparelho."),
            Result("Dispositivos USB conectados", if (usbDevices.isNotEmpty()) "OBSERVADO" else "NENHUM", if (usbDevices.isEmpty()) "Nenhum periférico USB está conectado no momento." else usbDevices.joinToString("; ") { d -> "${d.deviceName} VID=%04X PID=%04X interfaces=%d".format(d.vendorId, d.productId, d.interfaceCount) }),
            Result("Decisão adaptativa", "INFORMATIVO", "Modo recomendado: ${decision.mode}"),
            Result("Acesso ao tuner FM", "NÃO COMPROVADO", "Não existe confirmação de sintonia/áudio neste teste observacional. O laboratório não tenta contornar permissões, drivers, HAL ou bloqueios do fabricante."),
            Result("Clock / cristal / PLL", "NÃO EXPOSTO", "Frequência, estabilidade e topologia do cristal/PLL normalmente não são disponibilizadas a um app Android comum; nenhum valor foi presumido.")
        )
    }

    fun runAndSave(): String {
        val results = run()
        val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
        val text = buildString {
            append("FM-DX ANDROID — LABORATÓRIO DE HARDWARE 0.40.0\n")
            append("Execução: $stamp\n\n")
            results.forEach { append("[${it.status}] ${it.name}\n${it.detail}\n\n") }
            append("COMPARAÇÃO ENTRE APARELHOS\n")
            append(HardwareSignatureDatabase(context.applicationContext).comparisonSummary())
            append("\n\n")
            append("LEITURA DOS RESULTADOS\n")
            append("COLETADO/OBSERVADO significa que o dado foi exposto ao aplicativo. INDÍCIO não equivale a suporte confirmado. A confirmação de FM exige teste real e específico do modelo/firmware.\n")
        }
        prefs.edit().putString("last_report", text).putLong("last_run_at", System.currentTimeMillis()).apply()
        HardwareSignatureDatabase(context.applicationContext).saveObservation(
            results.firstOrNull { it.name == "Acesso ao tuner FM" }?.status ?: "NÃO COMPROVADO"
        )
        return text
    }

    fun history(): String = prefs.getString("last_report", "Nenhum teste executado ainda.") ?: "Nenhum teste executado ainda."
    fun clear() { prefs.edit().clear().apply() }

    private fun audioTypeName(type: Int): String = when (type) {
        AudioDeviceInfo.TYPE_BUILTIN_EARPIECE -> "alto-falante auricular"
        AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> "alto-falante"
        AudioDeviceInfo.TYPE_WIRED_HEADSET -> "headset P2"
        AudioDeviceInfo.TYPE_WIRED_HEADPHONES -> "fone P2"
        AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_HEADSET -> "USB áudio"
        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP, AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> "Bluetooth áudio"
        AudioDeviceInfo.TYPE_HDMI, AudioDeviceInfo.TYPE_HDMI_ARC, AudioDeviceInfo.TYPE_HDMI_EARC -> "HDMI áudio"
        else -> "áudio tipo $type"
    }
}
