package br.com.fmdx.android.fm.lab

import android.content.Context
import br.com.fmdx.android.fm.core.AdaptiveRadioDecisionEngine
import br.com.fmdx.android.fm.detector.UniversalHardwareDetector
import br.com.fmdx.android.fm.evidence.EvidenceStatus
import br.com.fmdx.android.fm.matrix.DeviceEvidenceMatrix
import br.com.fmdx.android.fm.signature.SignatureGenerator

/** Executa uma sequência previsível de testes observacionais e mantém histórico local. */
class HardwareTestRunner(private val context: Context) {
    enum class Outcome { PASS, PARTIAL, NO_EVIDENCE, INFO }
    data class TestResult(val id: String, val name: String, val outcome: Outcome, val detail: String, val timestamp: Long)

    private val prefs = context.getSharedPreferences("fmdx_test_runner", Context.MODE_PRIVATE)
    private val repository = HistoricalTestRepository(context.applicationContext)

    fun runAll(): List<TestResult> {
        val now = System.currentTimeMillis()
        val profile = UniversalHardwareDetector(context.applicationContext).detect()
        val signature = SignatureGenerator.generate(profile)
        val decision = AdaptiveRadioDecisionEngine.evaluate(profile)
        val matrix = DeviceEvidenceMatrix.evaluate(profile)
        return listOf(
            TestResult("signature", "Assinatura do dispositivo", Outcome.PASS, "Fingerprint: ${signature.key}", now),
            TestResult("evidence", "Coleta de evidências", if (profile.evidence.isEmpty()) Outcome.NO_EVIDENCE else Outcome.PASS, "${profile.evidence.size} evidência(s) observável(is)", now),
            TestResult("confirmed", "Evidências confirmadas", if (profile.evidence.any { it.status == EvidenceStatus.CONFIRMED || it.status == EvidenceStatus.AVAILABLE }) Outcome.PASS else Outcome.NO_EVIDENCE, "Baseado somente no que o app consegue observar", now),
            TestResult("decision", "Decisão adaptativa", Outcome.INFO, "Modo recomendado: ${decision.mode}", now),
            TestResult("matrix", "Matriz do dispositivo", Outcome.INFO, "${matrix.classification} • ${matrix.score}/100", now),
            TestResult("tuner", "Acesso ao tuner", Outcome.NO_EVIDENCE, "Não comprovado automaticamente; nenhum bloqueio ou permissão é contornado", now)
        )
    }

    fun runAndSave(): String {
        val results = runAll()
        val report = format(results)
        prefs.edit().putString("last_report", report).apply()
        val profile = UniversalHardwareDetector(context.applicationContext).detect()
        val signature = SignatureGenerator.generate(profile).key
        val previous = repository.history(signature).lastOrNull()?.report
        repository.save(HistoricalTestRepository.Snapshot(signature, System.currentTimeMillis(), "0.22.0", report))
        return report + "\n\nHISTÓRICO\n" + TestResultComparator.compare(previous, report)
    }

    fun history(): String = prefs.getString("last_report", "Nenhuma execução do Test Runner ainda.") ?: "Nenhuma execução do Test Runner ainda."
    fun clear() { prefs.edit().clear().apply(); repository.clear() }

    private fun format(results: List<TestResult>): String = buildString {
        append("TEST RUNNER ESTRUTURADO — FM-DX\n\n")
        results.forEachIndexed { index, r ->
            append("${index + 1}. [${r.outcome}] ${r.name}\n")
            append("   ${r.detail}\n\n")
        }
        append("IMPORTANTE\n")
        append("Os resultados registram observações disponíveis ao aplicativo. PASS significa que o diagnóstico observou o item esperado; não significa controle irrestrito do rádio físico.")
    }
}
