package br.com.fmdx.android.tv

/**
 * Bounded presentation model for text-only ISDB-T captions.
 * Input must already be an extracted ARIB B24 text byte block; this class does
 * not demultiplex MPEG-TS/PES, parse ARIB data groups, or render bitmap/DRCS cues.
 */
data class IsdbtCaptionCue(
    val cueId: Long,
    val startTimeMs: Long,
    val endTimeMs: Long,
    val text: String,
    val languageTag: String? = null
)

data class IsdbtCaptionSnapshot(
    val cues: List<IsdbtCaptionCue>,
    val latestCue: IsdbtCaptionCue?,
    val rejectedCount: Int
)

class IsdbtCaptionTimeline(
    private val decoder: AribB24Decoder = AribB24Decoder(),
    private val maxCues: Int = DEFAULT_MAX_CUES
) {
    private val cues = ArrayDeque<IsdbtCaptionCue>()
    private val seenIds = LinkedHashSet<Long>()
    private var rejected = 0

    init { require(maxCues in 1..1000) { "maxCues must be between 1 and 1000" } }

    @Synchronized
    fun addTextBlock(
        cueId: Long,
        startTimeMs: Long,
        durationMs: Long,
        aribTextBytes: ByteArray,
        languageTag: String? = null
    ): IsdbtCaptionSnapshot {
        if (cueId < 0 || startTimeMs < 0 || durationMs !in 1..MAX_CUE_DURATION_MS ||
            startTimeMs > Long.MAX_VALUE - durationMs || aribTextBytes.isEmpty() || aribTextBytes.size > MAX_TEXT_BYTES ||
            cueId in seenIds) {
            rejected++
            return snapshot()
        }
        val decoded = decoder.decode(aribTextBytes).trim()
        if (decoded.isBlank()) {
            rejected++
            return snapshot()
        }
        val cue = IsdbtCaptionCue(cueId, startTimeMs, startTimeMs + durationMs, decoded,
            languageTag?.takeIf { it.length in 2..16 && it.all { ch -> ch.isLetterOrDigit() || ch == '-' } })
        cues.add(cue)
        seenIds.add(cueId)
        while (cues.size > maxCues) {
            val removed = cues.removeFirst()
            seenIds.remove(removed.cueId)
        }
        return snapshot()
    }

    @Synchronized
    fun activeAt(timeMs: Long): IsdbtCaptionCue? = cues.lastOrNull { timeMs >= it.startTimeMs && timeMs < it.endTimeMs }

    @Synchronized
    fun snapshot() = IsdbtCaptionSnapshot(cues.toList(), cues.lastOrNull(), rejected)

    @Synchronized
    fun clear() { cues.clear(); seenIds.clear(); rejected = 0 }

    companion object {
        const val DEFAULT_MAX_CUES = 200
        const val MAX_TEXT_BYTES = 4096
        const val MAX_CUE_DURATION_MS = 10 * 60 * 1000L
    }
}
