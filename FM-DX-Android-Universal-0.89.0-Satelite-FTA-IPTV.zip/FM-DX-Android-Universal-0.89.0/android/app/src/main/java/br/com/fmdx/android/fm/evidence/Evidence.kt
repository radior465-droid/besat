package br.com.fmdx.android.fm.evidence

enum class EvidenceStatus { CONFIRMED, PROBABLE, OBSERVED, NOT_AVAILABLE, UNKNOWN }
enum class AccessLevel { PUBLIC, PARTIAL, BLOCKED, UNKNOWN }

data class Evidence(
    val type: String,
    val source: String,
    val value: String,
    val status: EvidenceStatus,
    val confidence: Int,
    val access: AccessLevel = AccessLevel.UNKNOWN
)
