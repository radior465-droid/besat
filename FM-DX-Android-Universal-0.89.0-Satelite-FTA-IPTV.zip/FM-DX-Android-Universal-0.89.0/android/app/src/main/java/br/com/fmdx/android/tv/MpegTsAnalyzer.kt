package br.com.fmdx.android.tv

/** Resultado da inspeção de um pacote MPEG Transport Stream de 188 bytes. */
data class MpegTsPacket(
    val pid: Int,
    val transportError: Boolean,
    val payloadUnitStart: Boolean,
    val transportPriority: Boolean,
    val scramblingControl: Int,
    val adaptationFieldControl: Int,
    val continuityCounter: Int
)

data class MpegTsStreamStats(
    val packets: Int,
    val syncErrors: Int,
    val transportErrors: Int,
    val scrambledPackets: Int,
    val nullPackets: Int,
    val distinctPids: Int
)

/** Parser MPEG-TS independente de hardware. Não sintoniza nem captura RF. */
object MpegTsAnalyzer {
    const val PACKET_SIZE = 188
    private const val SYNC_BYTE = 0x47

    fun parsePacket(bytes: ByteArray, offset: Int = 0): MpegTsPacket? {
        if (offset < 0 || bytes.size - offset < PACKET_SIZE) return null
        val b0 = bytes[offset].toInt() and 0xff
        if (b0 != SYNC_BYTE) return null
        val b1 = bytes[offset + 1].toInt() and 0xff
        val b2 = bytes[offset + 2].toInt() and 0xff
        val b3 = bytes[offset + 3].toInt() and 0xff
        val afc = (b3 ushr 4) and 0x03
        if (afc == 0) return null // reservado pelo padrão
        return MpegTsPacket(
            pid = ((b1 and 0x1f) shl 8) or b2,
            transportError = (b1 and 0x80) != 0,
            payloadUnitStart = (b1 and 0x40) != 0,
            transportPriority = (b1 and 0x20) != 0,
            scramblingControl = (b3 ushr 6) and 0x03,
            adaptationFieldControl = afc,
            continuityCounter = b3 and 0x0f
        )
    }

    /** Analisa pacotes alinhados em blocos de 188 bytes; bytes restantes são ignorados. */
    fun analyze(data: ByteArray): MpegTsStreamStats {
        var packets = 0; var syncErrors = 0; var transportErrors = 0
        var scrambled = 0; var nulls = 0
        val pids = HashSet<Int>()
        var offset = 0
        while (offset + PACKET_SIZE <= data.size) {
            val packet = parsePacket(data, offset)
            if (packet == null) syncErrors++ else {
                packets++; pids.add(packet.pid)
                if (packet.transportError) transportErrors++
                if (packet.scramblingControl != 0) scrambled++
                if (packet.pid == 0x1fff) nulls++
            }
            offset += PACKET_SIZE
        }
        return MpegTsStreamStats(packets, syncErrors, transportErrors, scrambled, nulls, pids.size)
    }
}

/** Contrato para futuros backends USB; a implementação depende do chipset e driver. */
interface TvTransportSource {
    val sourceName: String
    val isAvailable: Boolean
    /** Retorna bytes MPEG-TS já entregues pelo driver; null significa sem dados. */
    fun readTransportChunk(): ByteArray?
}
