package br.com.fmdx.android.integration

import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * LAN transport for FM-DX peer monitoring. Audio must be supplied by a real, permitted
 * FM/audio backend via publishAudio(); this class does not access or unlock the FM tuner.
 * Protocol: type byte + payload length (int) + UTF-8 JSON (type 1) or PCM bytes (type 2).
 */
class LanRadioBridge(private val listener: Listener) {
    interface Listener {
        fun onStatus(message: String)
        fun onMetadata(metadata: JSONObject)
        fun onAudioFrame(pcm: ByteArray)
    }

    companion object { const val DEFAULT_PORT = 45872; private const val MAX_PACKET = 1_048_576 }
    private val running = AtomicBoolean(false)
    private val executor = Executors.newCachedThreadPool()
    @Volatile private var server: ServerSocket? = null
    @Volatile private var socket: Socket? = null
    @Volatile private var output: DataOutputStream? = null
    private val writeLock = Any()

    fun startServer(token: String, port: Int = DEFAULT_PORT) {
        require(token.length in 4..32) { "Código deve ter entre 4 e 32 caracteres" }
        stop()
        running.set(true)
        executor.execute {
            try {
                val ss = ServerSocket(port)
                server = ss
                listener.onStatus("Aguardando outro celular na porta $port")
                val peer = ss.accept()
                attach(peer, token)
            } catch (e: Exception) { if (running.get()) listener.onStatus("Falha no servidor: ${e.message}") }
        }
    }

    fun connect(host: String, port: Int = DEFAULT_PORT, token: String) {
        require(token.length in 4..32) { "Código deve ter entre 4 e 32 caracteres" }
        stop()
        running.set(true)
        executor.execute {
            try {
                listener.onStatus("Conectando a $host:$port…")
                attach(Socket(host, port).apply { soTimeout = 0 }, token)
            } catch (e: Exception) { if (running.get()) listener.onStatus("Falha na conexão: ${e.message}") }
        }
    }

    private fun attach(peer: Socket, token: String) {
        socket = peer
        peer.tcpNoDelay = true
        val input = DataInputStream(BufferedInputStream(peer.getInputStream()))
        val out = DataOutputStream(BufferedOutputStream(peer.getOutputStream()))
        output = out
        // Both sides exchange a small shared-code handshake. This is not encryption.
        synchronized(writeLock) { out.writeUTF(token); out.flush() }
        val remoteToken = input.readUTF()
        if (remoteToken != token) throw SecurityException("Código de pareamento incorreto")
        listener.onStatus("Conectado: ${peer.inetAddress.hostAddress}")
        while (running.get() && !peer.isClosed) {
            val type = input.readUnsignedByte()
            val size = input.readInt()
            if (size !in 0..MAX_PACKET) throw IllegalStateException("Pacote inválido: $size bytes")
            val payload = ByteArray(size)
            input.readFully(payload)
            when (type) {
                1 -> listener.onMetadata(JSONObject(payload.toString(Charsets.UTF_8)))
                2 -> listener.onAudioFrame(payload)
                else -> throw IllegalStateException("Tipo de pacote desconhecido")
            }
        }
    }

    fun publishMetadata(metadata: JSONObject) = send(1, metadata.toString().toByteArray(Charsets.UTF_8))
    fun publishAudio(pcm: ByteArray) { if (pcm.isNotEmpty() && pcm.size <= MAX_PACKET) send(2, pcm) }

    private fun send(type: Int, payload: ByteArray) {
        val out = output ?: return
        synchronized(writeLock) {
            try { out.writeByte(type); out.writeInt(payload.size); out.write(payload); out.flush() }
            catch (e: Exception) { listener.onStatus("Envio interrompido: ${e.message}"); stop() }
        }
    }

    fun stop() {
        running.set(false)
        try { socket?.close() } catch (_: Exception) {}
        try { server?.close() } catch (_: Exception) {}
        socket = null; server = null; output = null
        listener.onStatus("Desconectado")
    }

    fun close() { stop(); executor.shutdownNow() }

    fun localIpv4(): String? = try {
        NetworkInterface.getNetworkInterfaces().toList().asSequence()
            .filter { it.isUp && !it.isLoopback }
            .flatMap { it.inetAddresses.toList().asSequence() }
            .filterIsInstance<Inet4Address>()
            .firstOrNull { !it.isLoopbackAddress }?.hostAddress
    } catch (_: Exception) { null }
}
