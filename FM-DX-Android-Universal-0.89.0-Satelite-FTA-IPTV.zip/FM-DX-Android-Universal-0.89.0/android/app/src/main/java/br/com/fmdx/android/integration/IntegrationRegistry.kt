package br.com.fmdx.android.integration

/**
 * Runtime registry for UI/diagnostics. It does not claim hardware support;
 * callers must set states from real probes or backend evidence.
 */
object IntegrationRegistry {
    private val statuses = linkedMapOf<String, CapabilityStatus>()

    fun update(status: CapabilityStatus) { statuses[status.id] = status }
    fun get(id: String): CapabilityStatus? = statuses[id]
    fun snapshot(): List<CapabilityStatus> = statuses.values.toList()
    fun clear() = statuses.clear()

    fun seedDefaults() {
        if (statuses.isNotEmpty()) return
        update(CapabilityStatus("fm", "FM nativo", CapabilityState.UNKNOWN, "Aguardando backend e permissões"))
        update(CapabilityStatus("video", "Vídeo/stream", CapabilityState.EXPERIMENTAL, "Depende de formato, codec e fonte"))
        update(CapabilityStatus("usb_tv", "TV USB", CapabilityState.DRIVER_REQUIRED, "Requer hardware e driver compatíveis"))
        update(CapabilityStatus("dsp", "Rádio virtual / DSP", CapabilityState.AVAILABLE, "Processamento local do aplicativo"))
    }
}
