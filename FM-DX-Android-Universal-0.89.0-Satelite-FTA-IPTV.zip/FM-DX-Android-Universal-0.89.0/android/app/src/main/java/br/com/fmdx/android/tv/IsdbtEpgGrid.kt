package br.com.fmdx.android.tv

import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

/** View-model for a channel-oriented EPG. Times in SI are UTC; presentation uses the chosen zone. */
data class EpgProgramCell(
    val serviceId: Int,
    val channelName: String,
    val eventId: Int,
    val title: String,
    val summary: String?,
    val start: Instant?,
    val end: Instant?,
    val timeLabel: String,
    val durationLabel: String
)

data class EpgChannelRow(val serviceId: Int, val channelName: String, val programs: List<EpgProgramCell>)
data class IsdbtEpgGrid(val channels: List<EpgChannelRow>, val programCount: Int, val missingTimeCount: Int)

object IsdbtEpgGridBuilder {
    fun build(snapshot: IsdbtSiSnapshot, zone: ZoneId = ZoneId.systemDefault()): IsdbtEpgGrid {
        val names = snapshot.services.associate { it.serviceId to (it.serviceName?.takeIf(String::isNotBlank) ?: "Canal ${it.serviceId}") }
        val time = DateTimeFormatter.ofPattern("HH:mm").withZone(zone)
        val cells = snapshot.events.map { event ->
            val start = event.startTimeUtc?.let { runCatching { Instant.parse(it) }.getOrNull() }
            val end = if (start != null && event.durationSeconds != null && event.durationSeconds >= 0)
                runCatching { start.plusSeconds(event.durationSeconds.toLong()) }.getOrNull() else null
            val label = if (start != null) time.format(start) else "Horário indisponível"
            val duration = event.durationSeconds?.takeIf { it >= 0 }?.let { seconds ->
                val h = seconds / 3600; val m = (seconds % 3600) / 60
                if (h > 0) "${h}h ${m}min" else "${m}min"
            } ?: "Duração indisponível"
            EpgProgramCell(event.serviceId, names[event.serviceId] ?: "Canal ${event.serviceId}", event.eventId,
                event.title?.takeIf(String::isNotBlank) ?: "Programa sem título", event.summary, start, end, label, duration)
        }
        val rows = cells.groupBy { it.serviceId }.map { (id, programs) ->
            EpgChannelRow(id, names[id] ?: "Canal $id", programs.sortedWith(compareBy({ it.start == null }, { it.start ?: Instant.MAX }, { it.eventId })))
        }.sortedBy { it.channelName.lowercase() }
        return IsdbtEpgGrid(rows, cells.size, cells.count { it.start == null })
    }
}
