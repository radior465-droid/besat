package br.com.fmdx.android.tv

/** Service-level view discovered from a live MPEG-TS packet stream. */
data class DiscoveredTvService(
    val programNumber: Int,
    val pmtPid: Int,
    val pcrPid: Int,
    val videoPids: List<Int>,
    val audioPids: List<Int>,
    val otherPids: List<Int>,
    val streamTypes: List<Int>
)

data class TvDiscoverySnapshot(
    val patValid: Boolean,
    val programsExpected: Int,
    val services: List<DiscoveredTvService>,
    val rejectedPsiSections: Int
)

/**
 * Incremental PAT -> PMT discovery over 188-byte MPEG-TS packets.
 * CRC is checked before parsed table data is trusted. This does not tune RF,
 * decode descriptors, identify a broadcaster's logical channel number, or play A/V.
 */
class TvServiceDiscovery {
    private val patAssembler = PsiSectionAssembler(0x0000)
    private val pmtAssemblers = linkedMapOf<Int, PsiSectionAssembler>()
    private val programToPmtPid = linkedMapOf<Int, Int>()
    private val services = linkedMapOf<Int, DiscoveredTvService>()
    private var patValid = false
    private var rejected = 0

    @Synchronized fun reset() {
        patAssembler.reset(); pmtAssemblers.values.forEach { it.reset() }
        pmtAssemblers.clear(); programToPmtPid.clear(); services.clear()
        patValid = false; rejected = 0
    }

    /** Feed exactly one 188-byte packet. Returns a fresh snapshot after processing. */
    @Synchronized fun feed(packet: ByteArray): TvDiscoverySnapshot {
        val header = MpegTsAnalyzer.parsePacket(packet)
        if (header == null || header.transportError || header.scramblingControl != 0) return snapshot()
        val assembler = if (header.pid == 0) patAssembler else pmtAssemblers[header.pid]
        if (assembler != null) {
            for (section in assembler.feed(packet)) {
                if (!MpegPsiCrc32.isValidSection(section)) { rejected++; continue }
                when (section[0].toInt() and 0xFF) {
                    0x00 -> acceptPat(section)
                    0x02 -> acceptPmt(section, header.pid)
                }
            }
        }
        return snapshot()
    }

    @Synchronized fun snapshot(): TvDiscoverySnapshot = TvDiscoverySnapshot(
        patValid, programToPmtPid.size, services.values.sortedBy { it.programNumber }, rejected
    )

    private fun acceptPat(section: ByteArray) {
        val entries = TvProgramTableParser.parsePat(section)
        if (entries.isEmpty()) { rejected++; return }
        patValid = true
        val next = entries.associate { it.programNumber to it.pmtPid }
        if (next != programToPmtPid) {
            programToPmtPid.clear(); programToPmtPid.putAll(next)
            services.keys.retainAll(next.keys)
            pmtAssemblers.keys.retainAll(next.values.toSet())
            next.values.forEach { pid -> pmtAssemblers.getOrPut(pid) { PsiSectionAssembler(pid) } }
        }
    }

    private fun acceptPmt(section: ByteArray, pid: Int) {
        val pmt = TvProgramTableParser.parsePmt(section) ?: run { rejected++; return }
        if (programToPmtPid[pmt.programNumber] != pid) return
        val videoTypes = setOf(0x01, 0x02, 0x10, 0x1B, 0x24, 0x42)
        val audioTypes = setOf(0x03, 0x04, 0x0F, 0x11, 0x81, 0x87)
        services[pmt.programNumber] = DiscoveredTvService(
            pmt.programNumber, pid, pmt.pcrPid,
            pmt.streams.filter { it.streamType in videoTypes }.map { it.elementaryPid },
            pmt.streams.filter { it.streamType in audioTypes }.map { it.elementaryPid },
            pmt.streams.filter { it.streamType !in videoTypes && it.streamType !in audioTypes }.map { it.elementaryPid },
            pmt.streams.map { it.streamType }
        )
    }
}
