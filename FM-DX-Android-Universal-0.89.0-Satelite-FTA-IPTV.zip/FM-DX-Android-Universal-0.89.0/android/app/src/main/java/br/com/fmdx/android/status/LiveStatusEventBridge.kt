package br.com.fmdx.android.status

import br.com.fmdx.android.events.MediaEvent
import br.com.fmdx.android.events.MediaEventManager

/** Bridges runtime events into a single dashboard snapshot. */
class LiveStatusEventBridge {
    @Volatile var usbStatus: String = "DISCONNECTED"; private set
    @Volatile var playerStatus: String = "IDLE"; private set
    @Volatile var fmStatus: String = "UNKNOWN"; private set
    @Volatile var mediaType: String = "UNKNOWN"; private set

    private val listener: (MediaEvent) -> Unit = { event ->
        when (event) {
            is MediaEvent.UsbChanged -> usbStatus = if (event.connected) "DETECTED" else "DISCONNECTED"
            is MediaEvent.PlayerStateChanged -> playerStatus = event.state.name
            is MediaEvent.FmStatusChanged -> fmStatus = event.status
            is MediaEvent.SourceClassified -> mediaType = event.sourceType
        }
    }

    fun start() = MediaEventManager.subscribe(listener)
    fun stop() = MediaEventManager.unsubscribe(listener)
}
