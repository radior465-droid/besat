package br.com.fmdx.android.tv

/** Names/events extracted from MPEG SI descriptors using the supported ARIB STD-B24 subset. */
data class IsdbtServiceInfo(
    val serviceId: Int,
    val serviceType: Int?,
    val providerName: String?,
    val serviceName: String?
)

data class IsdbtEventInfo(
    val serviceId: Int,
    val eventId: Int,
    val startTimeUtc: String?,
    val durationSeconds: Int?,
    val title: String?,
    val summary: String?
)

data class IsdbtSiSnapshot(val services: List<IsdbtServiceInfo>, val events: List<IsdbtEventInfo>, val ignoredSections: Int)

/** Parses SDT (0x42/0x46) and EIT (0x4E..0x6F) sections after CRC validation. */
class IsdbtSiParser {
    private val services = linkedMapOf<Int, IsdbtServiceInfo>()
    private val events = linkedMapOf<Pair<Int, Int>, IsdbtEventInfo>()
    private var ignored = 0
    private val textDecoder = AribB24Decoder()

    @Synchronized fun reset() { services.clear(); events.clear(); ignored = 0 }

    @Synchronized fun feed(section: ByteArray): IsdbtSiSnapshot {
        if (!MpegPsiCrc32.isValidSection(section)) { ignored++; return snapshot() }
        when (section[0].toInt() and 0xFF) {
            0x42, 0x46 -> parseSdt(section)
            in 0x4E..0x6F -> parseEit(section)
            else -> ignored++
        }
        return snapshot()
    }

    @Synchronized fun snapshot() = IsdbtSiSnapshot(services.values.sortedBy { it.serviceId }, events.values.sortedWith(compareBy({ it.serviceId }, { it.startTimeUtc ?: "" })), ignored)

    private fun parseSdt(s: ByteArray) {
        if (s.size < 15) { ignored++; return }
        var p = 11 // transport_stream_id(2), version/current(1), section/last(2), original_network_id(2), reserved(1)
        val end = s.size - 4
        while (p + 5 <= end) {
            val id = u16(s, p); val flags = u16(s, p + 3)
            val loopLen = flags and 0x0FFF
            p += 5
            if (p + loopLen > end) { ignored++; return }
            var serviceType: Int? = null; var provider: String? = null; var name: String? = null
            descriptors(s, p, p + loopLen) { tag, data, off, len ->
                if (tag == 0x48 && len >= 3) {
                    serviceType = u8(data, off)
                    val providerLen = u8(data, off + 1)
                    if (2 + providerLen < len) {
                        provider = decode(data, off + 2, providerLen)
                        val nameLenPos = off + 2 + providerLen
                        val nameLen = u8(data, nameLenPos)
                        if (3 + providerLen + nameLen <= len) name = decode(data, nameLenPos + 1, nameLen)
                    }
                }
            }
            services[id] = IsdbtServiceInfo(id, serviceType, provider, name)
            p += loopLen
        }
    }

    private fun parseEit(s: ByteArray) {
        if (s.size < 18) { ignored++; return }
        val serviceId = u16(s, 3); var p = 14; val end = s.size - 4
        while (p + 12 <= end) {
            val eventId = u16(s, p)
            val start = decodeMjdTime(s, p + 2)
            val duration = decodeDuration(s, p + 7)
            val loopLen = ((u8(s, p + 10) and 0x0F) shl 8) or u8(s, p + 11)
            p += 12
            if (p + loopLen > end) { ignored++; return }
            var title: String? = null; var summary: String? = null
            descriptors(s, p, p + loopLen) { tag, data, off, len ->
                if (tag == 0x4D && len >= 5) {
                    val titleLen = u8(data, off + 3)
                    if (4 + titleLen < len) {
                        title = decode(data, off + 4, titleLen)
                        val textLenPos = off + 4 + titleLen
                        val textLen = u8(data, textLenPos)
                        if (5 + titleLen + textLen <= len) summary = decode(data, textLenPos + 1, textLen)
                    }
                }
            }
            events[serviceId to eventId] = IsdbtEventInfo(serviceId, eventId, start, duration, title, summary)
            p += loopLen
        }
    }

    private inline fun descriptors(data: ByteArray, start: Int, end: Int, visit: (Int, ByteArray, Int, Int) -> Unit) {
        var p = start
        while (p + 2 <= end) {
            val tag = u8(data, p); val len = u8(data, p + 1); p += 2
            if (p + len > end) return
            visit(tag, data, p, len); p += len
        }
    }

    private fun decode(data: ByteArray, offset: Int, length: Int) = textDecoder.decode(data, offset, length)
    private fun decodeDuration(s: ByteArray, p: Int): Int? {
        val h = bcd(s, p) ?: return null; val m = bcd(s, p + 1) ?: return null; val sec = bcd(s, p + 2) ?: return null
        if (m > 59 || sec > 59) return null
        return h * 3600 + m * 60 + sec
    }
    private fun decodeMjdTime(s: ByteArray, p: Int): String? {
        val mjd = u16(s, p); val h = bcd(s, p + 2) ?: return null; val m = bcd(s, p + 3) ?: return null; val sec = bcd(s, p + 4) ?: return null
        if (h > 23 || m > 59 || sec > 59) return null
        val z = java.time.LocalDate.of(1858, 11, 17).plusDays(mjd.toLong()).atTime(h, m, sec)
        return z.toString() + "Z"
    }
    private fun bcd(s: ByteArray, p: Int): Int? { val v = u8(s, p); val a = v ushr 4; val b = v and 15; return if (a > 9 || b > 9) null else a * 10 + b }
    private fun u8(s: ByteArray, p: Int) = s[p].toInt() and 0xFF
    private fun u16(s: ByteArray, p: Int) = (u8(s, p) shl 8) or u8(s, p + 1)
}
