package br.com.fmdx.android.fm.profile

import android.os.Build

/**
 * Catálogo de famílias Android para orientar o diagnóstico multimarcas.
 * A marca identifica o fabricante do aparelho; não comprova a presença de tuner FM.
 */
object BrandCompatibilityCatalog {
    data class BrandInfo(val family: String, val aliases: List<String>, val note: String)

    private val brands = listOf(
        BrandInfo("Samsung", listOf("samsung"), "Verificar Exynos/Qualcomm e serviços Samsung; suporte depende do modelo e firmware."),
        BrandInfo("Motorola", listOf("motorola", "motorola mobility"), "Verificar plataforma Qualcomm/MediaTek e disponibilidade do backend no firmware."),
        BrandInfo("Xiaomi", listOf("xiaomi", "redmi", "poco"), "Verificar modelo exato, variante regional e plataforma Qualcomm/MediaTek."),
        BrandInfo("OPPO", listOf("oppo"), "Verificar plataforma e serviços de rádio específicos do firmware."),
        BrandInfo("Realme", listOf("realme"), "Verificar plataforma e variante regional do aparelho."),
        BrandInfo("vivo", listOf("vivo", "iqoo"), "Verificar plataforma e serviços do fabricante."),
        BrandInfo("OnePlus", listOf("oneplus"), "Verificar plataforma e componentes do firmware OxygenOS."),
        BrandInfo("Huawei", listOf("huawei"), "Verificar Kirin/Qualcomm/MediaTek conforme modelo e firmware."),
        BrandInfo("Honor", listOf("honor"), "Verificar plataforma e firmware específico do modelo."),
        BrandInfo("Sony", listOf("sony", "sony ericsson"), "Verificar modelo, chipset e backend disponibilizado pelo sistema."),
        BrandInfo("LG", listOf("lge", "lg electronics"), "Verificar chipset e serviços legados de rádio."),
        BrandInfo("HTC", listOf("htc"), "Verificar chipset e implementação legada do fabricante."),
        BrandInfo("ASUS", listOf("asus"), "Verificar variante e plataforma do aparelho."),
        BrandInfo("Nokia / HMD", listOf("nokia", "hmd global"), "Verificar plataforma e firmware da variante."),
        BrandInfo("Google Pixel", listOf("google"), "Verificar Tensor/Qualcomm conforme geração; marca não implica tuner FM."),
        BrandInfo("Lenovo", listOf("lenovo"), "Verificar modelo e plataforma; pode compartilhar famílias de hardware Motorola."),
        BrandInfo("ZTE", listOf("zte"), "Verificar plataforma e firmware regional."),
        BrandInfo("TCL", listOf("tcl", "alcatel"), "Verificar modelo, chipset e serviços de rádio."),
        BrandInfo("Transsion", listOf("tecno", "infinix", "itel"), "Verificar modelo e plataforma MediaTek/Unisoc."),
        BrandInfo("Outros Android", emptyList(), "Fabricante fora do catálogo: usar identificação por plataforma e evidências do sistema.")
    )

    fun identify(): BrandInfo {
        val value = listOf(Build.MANUFACTURER, Build.BRAND).joinToString(" ").lowercase()
        return brands.firstOrNull { it.aliases.any(value::contains) } ?: brands.last()
    }
}
