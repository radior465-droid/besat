package br.com.fmdx.android.fm.database

/**
 * Analisa grupos de observações coletadas localmente. A semelhança de plataforma
 * serve apenas para priorizar investigação; nunca comprova tuner, driver ou FM.
 */
object CrossDeviceCohortAnalyzer {
    data class Cohort(
        val platformFamily: String,
        val observationCount: Int,
        val distinctModels: List<String>,
        val distinctFirmwareCount: Int,
        val distinctSocModels: List<String>,
        val fmUnconfirmedCount: Int,
        val interpretation: String
    )

    fun analyze(
        observations: List<HardwareSignatureDatabase.DeviceObservation>,
        identify: (HardwareSignatureDatabase.DeviceObservation) -> String
    ): List<Cohort> {
        return observations.groupBy(identify).map { (family, items) ->
            val models = items.map { "${it.manufacturer} ${it.model}".trim() }
                .filter { it.isNotBlank() }.distinct().sorted()
            val socs = items.map { it.socModel.trim() }
                .filter { it.isNotBlank() && it != "API < 31" }.distinct().sorted()
            val firmwareCount = items.map { it.fingerprint }.filter { it.isNotBlank() }.distinct().size
            val unconfirmed = items.count { it.result.contains("NÃO COMPROVADO", ignoreCase = true) || it.result.contains("UNKNOWN", ignoreCase = true) }
            val interpretation = when {
                items.size < 2 -> "Apenas uma observação: não há comparação entre aparelhos."
                models.size > 1 && socs.size > 1 -> "Há modelos e identificações de SoC diferentes neste grupo; revisar variantes e evidências individualmente."
                models.size > 1 -> "Há mais de um modelo no grupo; semelhança de família não confirma componentes FM iguais."
                else -> "Observações do mesmo modelo/família; diferenças de firmware ainda podem alterar o acesso."
            }
            Cohort(family, items.size, models, firmwareCount, socs, unconfirmed, interpretation)
        }.sortedWith(compareByDescending<Cohort> { it.observationCount }.thenBy { it.platformFamily })
    }
}
