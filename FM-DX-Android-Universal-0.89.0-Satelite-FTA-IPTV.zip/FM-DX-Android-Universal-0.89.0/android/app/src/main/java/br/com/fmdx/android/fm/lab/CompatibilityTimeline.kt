package br.com.fmdx.android.fm.lab

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Linha do tempo local e visual dos snapshots de diagnóstico. */
class CompatibilityTimeline(context: Context) {
    private val repository = HistoricalTestRepository(context.applicationContext)
    private val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault())

    fun report(signature: String): String {
        val snapshots = repository.history(signature)
        if (snapshots.isEmpty()) {
            return "LINHA DO TEMPO DE COMPATIBILIDADE\n\nNenhuma execução histórica encontrada para esta assinatura. Execute o Test Runner Estruturado para criar o primeiro snapshot."
        }
        return buildString {
            append("LINHA DO TEMPO DE COMPATIBILIDADE\n\n")
            snapshots.forEachIndexed { index, snapshot ->
                append("● ${dateFormat.format(Date(snapshot.timestamp))}\n")
                append("  Versão: ${snapshot.version}\n")
                append("  Evento: execução #${index + 1}\n")
                if (index > 0) {
                    val previous = snapshots[index - 1]
                    append("  Comparação: ${TestResultComparator.compare(previous.report, snapshot.report)}\n")
                } else append("  Comparação: primeira execução registrada.\n")
                append("\n")
            }
            append("LEGENDA\n")
            append("● Cada ponto representa um diagnóstico local salvo. Mudanças mostram diferenças observáveis entre relatórios e não provam novo acesso ao tuner, PLL ou cristal.\n")
        }
    }
}
