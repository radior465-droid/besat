package br.com.fmdx.android.fm.matrix

import br.com.fmdx.android.fm.core.AdaptiveRadioDecisionEngine
import br.com.fmdx.android.fm.detector.UniversalHardwareDetector
import br.com.fmdx.android.fm.evidence.EvidenceStatus
import br.com.fmdx.android.fm.profile.HardwareProfile
import br.com.fmdx.android.fm.signature.SignatureGenerator

/**
 * Matriz local de evidências. Classifica somente o que o aplicativo consegue observar.
 * Não concede privilégios e não transforma indícios em acesso ao tuner.
 */
object DeviceEvidenceMatrix {
    enum class Classification { COMPATIBLE_CONFIRMED, PARTIALLY_INVESTIGABLE, VIRTUAL_ONLY }

    data class MatrixResult(
        val fingerprint: String,
        val classification: Classification,
        val score: Int,
        val nativeEvidence: Int,
        val unknownEvidence: Int,
        val totalEvidence: Int,
        val explanation: String
    ) {
        fun asText(): String = buildString {
            append("MATRIZ DE EVIDÊNCIAS DO DISPOSITIVO\n\n")
            append("Assinatura: $fingerprint\n")
            append("Classificação: $classification\n")
            append("Pontuação diagnóstica: $score/100\n\n")
            append("RESUMO DA MATRIZ\n")
            append("• Evidências observadas: $totalEvidence\n")
            append("• Evidências positivas/confirmadas: $nativeEvidence\n")
            append("• Evidências desconhecidas/parciais: $unknownEvidence\n\n")
            append("DECISÃO\n$explanation\n\n")
            append("IMPORTANTE\n")
            append("'COMPATIBLE_CONFIRMED' só é usado quando existe evidência positiva de interface acessível ao app; não significa, por si só, que todo tuner ou cristal possa ser controlado. A matriz não tenta contornar permissões, SELinux, drivers ou APIs bloqueadas.")
        }
    }

    fun evaluate(profile: HardwareProfile): MatrixResult {
        val signature = SignatureGenerator.generate(profile).key
        val decision = AdaptiveRadioDecisionEngine.evaluate(profile)
        val positive = profile.evidence.count { it.status == EvidenceStatus.CONFIRMED }
        val unknown = profile.evidence.count { it.status != EvidenceStatus.CONFIRMED && it.status != EvidenceStatus.AVAILABLE }
        val base = profile.confidenceScore.coerceIn(0, 100)
        val classification = when {
            positive > 0 && decision.mode.name.contains("NATIVE") -> Classification.COMPATIBLE_CONFIRMED
            profile.evidence.isNotEmpty() -> Classification.PARTIALLY_INVESTIGABLE
            else -> Classification.VIRTUAL_ONLY
        }
        val explanation = when (classification) {
            Classification.COMPATIBLE_CONFIRMED -> "Há evidência positiva e um caminho nativo investigável/exposto. É necessário validar cada operação real separadamente."
            Classification.PARTIALLY_INVESTIGABLE -> "Há sinais técnicos para diagnóstico e investigação, mas o controle real do tuner não está comprovado."
            Classification.VIRTUAL_ONLY -> "Não há evidência suficiente de interface FM acessível. O modo virtual é o fallback seguro recomendado."
        }
        return MatrixResult(signature, classification, base, positive, unknown, profile.evidence.size, explanation)
    }

    fun evaluate(context: android.content.Context): MatrixResult = evaluate(UniversalHardwareDetector(context.applicationContext).detect())
}
