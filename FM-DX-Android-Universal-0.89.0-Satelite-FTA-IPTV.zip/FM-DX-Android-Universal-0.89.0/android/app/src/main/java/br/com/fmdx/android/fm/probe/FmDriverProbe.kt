package br.com.fmdx.android.fm.probe

import android.content.Context
import android.os.Build
import br.com.fmdx.android.fm.DeviceProfileDetector
import br.com.fmdx.android.fm.FmRadioController
import br.com.fmdx.android.fm.profile.BrandCompatibilityCatalog

/**
 * Probe somente de evidências: não instala driver e não tenta contornar permissões.
 * Procura indícios de backend/vendor já presente no aparelho e informa o nível de acesso.
 */
class FmDriverProbe(private val context: Context, private val controller: FmRadioController) {
    data class Result(
        val state: String,
        val backend: String,
        val evidence: List<String>,
        val note: String
    ) {
        fun asText(): String = buildString {
            append("FM DRIVER PROBE 0.50.0\n\n")
            append("Estado: $state\n")
            append("Backend selecionado: $backend\n\n")
            append("EVIDÊNCIAS\n")
            if (evidence.isEmpty()) append("• Nenhuma evidência específica encontrada.\n")
            else evidence.forEach { append("• $it\n") }
            append("\nOBSERVAÇÃO\n$note")
        }
    }

    fun run(): Result {
        val profile = DeviceProfileDetector.detect()
        val evidence = mutableListOf<String>()
        val brand = BrandCompatibilityCatalog.identify()
        evidence += "Família de fabricante: ${brand.family}"
        evidence += "Orientação: ${brand.note}"
        evidence += "Fabricante: ${Build.MANUFACTURER.ifBlank { "desconhecido" }}"
        evidence += "Modelo: ${Build.MODEL.ifBlank { "desconhecido" }}"
        evidence += "Hardware: ${Build.HARDWARE.ifBlank { "não informado" }}"
        evidence += "Perfil SoC: ${profile.socManufacturer.ifBlank { "desconhecido" }} ${profile.socModel}".trim()
        evidence += profile.evidence.map { "Perfil: $it" }
        evidence += AndroidRadioFeatureSnapshot.collect(context)

        val nodeEvidence = RadioNodeEvidenceScanner.inspect()
        evidence += "Nós/caminhos conhecidos: ${RadioNodeEvidenceScanner.summary(nodeEvidence)}"
        evidence += nodeEvidence.filter { it.exists }.map { "Caminho: ${it.asText()}" }
        if (nodeEvidence.none { it.exists }) {
            evidence += "Nenhum dos caminhos conhecidos está visível; isso não prova ausência de hardware FM."
        }

        val vendorHints = listOf(
            "/vendor/lib/hw", "/vendor/lib64/hw", "/system/lib/hw", "/system/lib64/hw"
        ).filter { java.io.File(it).exists() }
        if (vendorHints.isNotEmpty()) evidence += "Diretórios HAL/vendor visíveis: ${vendorHints.joinToString()}"

        val state = when {
            controller.isSupported() -> "BACKEND_AVAILABLE"
            profile.backendId != "unknown" && profile.backendId.isNotBlank() -> "VENDOR_PROFILE_DETECTED"
            else -> "NO_CONFIRMED_BACKEND"
        }
        val note = when (state) {
            "BACKEND_AVAILABLE" -> "Um backend do aplicativo foi marcado como disponível; confirme sintonia e áudio no aparelho real. Recursos declarados pelo Android não comprovam, isoladamente, a presença de tuner FM."
            "VENDOR_PROFILE_DETECTED" -> "Há indícios de plataforma/vendor, mas isso não confirma tuner FM. Um APK comum pode não ter acesso ao driver/HAL FM do sistema."
            else -> "Nenhum backend FM confirmado foi encontrado por este probe. Isso não prova ausência física do rádio."
        }
        return Result(state, controller.backendName, evidence, note)
    }
}
