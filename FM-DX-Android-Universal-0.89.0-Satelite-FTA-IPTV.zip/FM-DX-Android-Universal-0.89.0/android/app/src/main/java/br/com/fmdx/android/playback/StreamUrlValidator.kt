package br.com.fmdx.android.playback

import java.net.URI

/** Validação conservadora para URLs entregues ao player nativo. */
object StreamUrlValidator {
    fun normalize(raw: String?): String? {
        val value = raw?.trim()?.takeIf { it.isNotEmpty() && it.length <= 4096 } ?: return null
        return try {
            val uri = URI(value)
            val scheme = uri.scheme?.lowercase()
            if ((scheme != "http" && scheme != "https") || uri.host.isNullOrBlank()) return null
            if (uri.userInfo != null) return null
            uri.toASCIIString()
        } catch (_: Exception) {
            null
        }
    }
}
