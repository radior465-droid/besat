package br.com.fmdx.android.fm.crystal

import android.os.Build
import br.com.fmdx.android.fm.profile.HardwareProfile

/**
 * Diagnóstico conceitual de clock/referência. Não acessa nem controla diretamente
 * o cristal físico; apenas registra dados públicos que ajudam a correlacionar a
 * plataforma com uma possível cadeia clock -> PLL -> tuner.
 */
data class CrystalClockReport(
    val status: String,
    val summary: String,
    val observations: List<String>
) {
    fun asText(): String = buildString {
        append("FM-DX — Crystal / Clock Diagnostics\n\n")
        append("Status: $status\n")
        append("$summary\n\n")
        append("OBSERVAÇÕES\n")
        observations.forEach { append("• $it\n") }
        append("\nLimite: o Android comum não oferece uma API universal para ler ou controlar diretamente o cristal de referência do rádio. Este relatório não altera PLL, clock ou frequência física.\n")
    }
}

object CrystalClockDiagnostics {
    fun inspect(profile: HardwareProfile): CrystalClockReport {
        val observations = mutableListOf<String>()
        observations += "Plataforma detectada: ${profile.platform}"
        observations += "Hardware Android: ${Build.HARDWARE.ifBlank { "não informado" }}"
        observations += "Board: ${Build.BOARD.ifBlank { "não informado" }}"
        observations += "Fingerprint de software disponível: ${Build.FINGERPRINT.take(120)}"
        observations += "Evidências públicas relacionadas: ${profile.evidence.count { it.type.contains("RADIO") || it.type.contains("SYSTEM_FEATURE") }}"
        observations += "Modelo técnico usado: referência de clock → PLL/tuner → demodulação → áudio."
        observations += "Nenhuma frequência de cristal é assumida sem documentação ou evidência exposta pelo driver."
        return CrystalClockReport(
            status = "DIAGNÓSTICO SOMENTE",
            summary = "Foram coletadas informações públicas para identificar a plataforma; não foi obtido acesso direto ao oscilador físico.",
            observations = observations
        )
    }
}
