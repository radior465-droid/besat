package br.com.fmdx.android.tv

import org.junit.Assert.*
import org.junit.Test
import java.time.ZoneId

class IsdbtEpgGridTest {
    @Test fun groupsEventsByServiceAndUsesChannelName() {
        val snapshot = IsdbtSiSnapshot(
            services = listOf(IsdbtServiceInfo(10, 1, "Rede", "Canal A"), IsdbtServiceInfo(20, 1, null, "Canal B")),
            events = listOf(
                IsdbtEventInfo(10, 2, "2026-11-17T13:00:00Z", 3600, "Jornal", "Resumo"),
                IsdbtEventInfo(10, 1, "2026-11-17T12:00:00Z", 1800, "Notícias", null),
                IsdbtEventInfo(20, 3, null, null, null, null)
            ), ignoredSections = 0)
        val grid = IsdbtEpgGridBuilder.build(snapshot, ZoneId.of("UTC"))
        assertEquals(2, grid.channels.size)
        val channel = grid.channels.first { it.serviceId == 10 }
        assertEquals("Canal A", channel.channelName)
        assertEquals(listOf("Notícias", "Jornal"), channel.programs.map { it.title })
        assertEquals("12:00", channel.programs.first().timeLabel)
        assertEquals("1h 0min", channel.programs.last().durationLabel)
        assertEquals(1, grid.missingTimeCount)
    }

    @Test fun emptySnapshotProducesEmptyGrid() {
        val grid = IsdbtEpgGridBuilder.build(IsdbtSiSnapshot(emptyList(), emptyList(), 0))
        assertTrue(grid.channels.isEmpty())
        assertEquals(0, grid.programCount)
    }
}
