package br.com.fmdx.android.fm.probe

import org.junit.Assert.assertTrue
import org.junit.Test

class RadioNodeEvidenceScannerTest {
    @Test
    fun candidateListContainsExpectedReadOnlyLocations() {
        assertTrue(RadioNodeEvidenceScanner.candidatePaths.contains("/dev/radio0"))
        assertTrue(RadioNodeEvidenceScanner.candidatePaths.contains("/sys/class/radio"))
        assertTrue(RadioNodeEvidenceScanner.candidatePaths.contains("/vendor/lib64"))
    }

    @Test
    fun summaryNeverClaimsFunctionalTuner() {
        val summary = RadioNodeEvidenceScanner.summary(emptyList())
        assertTrue(summary.contains("0/0"))
        assertTrue(summary.contains("não comprova tuner FM funcional"))
    }
}
