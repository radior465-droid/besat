package br.com.fmdx.android.playback

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class StreamUrlValidatorTest {
    @Test fun acceptsHttpAndHttps() {
        assertEquals("https://radio.example/live.mp3", StreamUrlValidator.normalize(" https://radio.example/live.mp3 "))
        assertEquals("http://radio.example:8080/live", StreamUrlValidator.normalize("http://radio.example:8080/live"))
    }

    @Test fun rejectsUnsupportedSchemesAndCredentials() {
        assertNull(StreamUrlValidator.normalize("file:///tmp/audio.mp3"))
        assertNull(StreamUrlValidator.normalize("javascript:alert(1)"))
        assertNull(StreamUrlValidator.normalize("https://user:pass@radio.example/live"))
    }

    @Test fun rejectsMalformedOrOversizedValues() {
        assertNull(StreamUrlValidator.normalize(null))
        assertNull(StreamUrlValidator.normalize("   "))
        assertNull(StreamUrlValidator.normalize("https:///missing-host"))
        assertNull(StreamUrlValidator.normalize("https://radio.example/" + "a".repeat(4100)))
    }
}
