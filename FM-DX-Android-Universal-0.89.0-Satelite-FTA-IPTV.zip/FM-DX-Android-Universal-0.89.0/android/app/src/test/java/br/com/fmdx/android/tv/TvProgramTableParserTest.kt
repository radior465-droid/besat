package br.com.fmdx.android.tv

import org.junit.Assert.*
import org.junit.Test

class TvProgramTableParserTest {
    @Test fun parsesPatAndSkipsNetworkEntry() {
        // Complete PAT with network PID entry and one television program; CRC bytes are placeholders.
        val s = byteArrayOf(0x00, 0xb0.toByte(), 0x11, 0x00, 0x01, 0xc1.toByte(), 0x00, 0x00,
            0x00, 0x00, 0xe0.toByte(), 0x10, 0x00, 0x01, 0xe1.toByte(), 0x00,
            0, 0, 0, 0)
        assertEquals(listOf(TvProgramEntry(1, 0x100)), TvProgramTableParser.parsePat(s))
    }

    @Test fun rejectsWrongTableAndTruncatedSection() {
        assertTrue(TvProgramTableParser.parsePat(byteArrayOf(2, 0, 0)).isEmpty())
        assertNull(TvProgramTableParser.parsePmt(byteArrayOf(2, 0xb0.toByte(), 0x20)))
    }

    @Test fun parsesPmtElementaryStream() {
        val s = byteArrayOf(0x02, 0xb0.toByte(), 0x12, 0x00, 0x01, 0xc1.toByte(), 0, 0,
            0xe1.toByte(), 0x00, 0xf0.toByte(), 0,
            0x1b, 0xe1.toByte(), 0x01, 0xf0.toByte(), 0,
            0, 0, 0, 0)
        val pmt = TvProgramTableParser.parsePmt(s)!!
        assertEquals(1, pmt.programNumber)
        assertEquals(0x100, pmt.pcrPid)
        assertEquals(listOf(TvElementaryStream(0x1b, 0x101)), pmt.streams)
    }
}
