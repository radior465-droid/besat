package br.com.fmdx.android.tv

import org.junit.Assert.assertEquals
import org.junit.Test

class AribB24DecoderTest {
    @Test fun decodesDesignatedAlphanumericSet() {
        val bytes = byteArrayOf(0x1b, 0x28, 0x4a, 'N'.code.toByte(), 'H'.code.toByte(), 'K'.code.toByte())
        assertEquals("NHK", AribB24Decoder().decode(bytes))
    }

    @Test fun decodesHiraganaAndKatakanaFromJisRows() {
        val hira = byteArrayOf(0x1b, 0x28, 0x30, 0x22, 0x1b, 0x28, 0x31, 0x22)
        assertEquals("あア", AribB24Decoder().decode(hira))
    }

    @Test fun supportsLockingShiftToAlphanumeric() {
        val bytes = byteArrayOf(0x0e, 'T'.code.toByte(), 'V'.code.toByte())
        assertEquals("TV", AribB24Decoder().decode(bytes))
    }

    @Test fun decodesHiraganaThroughInitialGrSet() {
        assertEquals("あ", AribB24Decoder().decode(byteArrayOf(0xa2.toByte())))
    }

    @Test fun decodesSingleShiftToG2() {
        assertEquals("あ", AribB24Decoder().decode(byteArrayOf(0x19, 0x22)))
    }

    @Test fun truncatedKanjiPairDoesNotCrash() {
        assertEquals("", AribB24Decoder().decode(byteArrayOf(0x24)))
    }

    @Test fun malformedSliceAndOverflowingLengthReturnEmptyText() {
        val decoder = AribB24Decoder()
        assertEquals("", decoder.decode(byteArrayOf(1, 2), 2, 4))
        assertEquals("", decoder.decode(byteArrayOf(1, 2), 1, Int.MAX_VALUE))
    }
}
