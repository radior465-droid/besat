# Regras adicionais de shrinker serão adicionadas quando o app usar bibliotecas externas.
