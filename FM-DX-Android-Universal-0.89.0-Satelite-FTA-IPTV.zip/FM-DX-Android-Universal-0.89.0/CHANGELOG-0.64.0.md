# FM-DX Android Universal 0.64.0 — Fila Inteligente

## Novidades
- Avanço automático para o próximo canal da fila quando a mídia termina.
- Botões de canal anterior e próximo da fila.
- Estados de reprodução: reproduzindo, aguardando dados, encerrado e falha.
- Leitura defensiva do armazenamento local: JSON inválido não impede a abertura da central.
- Limites anteriores de 100 itens na fila e 30 no histórico preservados.

## Segurança e limitações
- Aceita somente URLs HTTP/HTTPS sem credenciais embutidas.
- Não contorna DRM, autenticação, CORS ou bloqueios do servidor.
- Reprodução depende do navegador, codec e permissões da fonte.
- Estado permanece local neste navegador.
