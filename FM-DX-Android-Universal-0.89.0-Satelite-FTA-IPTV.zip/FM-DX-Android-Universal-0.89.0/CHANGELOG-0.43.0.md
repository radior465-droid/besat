# FM-DX Android Universal 0.43.0 — LAN Radio Bridge

## Added
- Peer-to-peer TCP bridge for two Android devices on the same Wi-Fi/LAN.
- Receiver/server mode and sender/client mode with configurable port.
- Shared-code handshake to prevent accidental connections to an unintended peer.
- Versioned-by-type framed transport for JSON station metadata and PCM audio payloads.
- Metadata test action for frequency/RDS demonstration.
- Explicit lifecycle cleanup when the activity is destroyed.

## Important limitations
- The bridge transports data; it does not tune FM hardware, decode RDS, or capture internal FM audio by itself.
- `publishAudio(pcm)` is the integration point for a future FM/audio backend that has lawful access to PCM frames.
- The current demo sends synthetic metadata only. No real frequency or RDS is claimed.
- The shared code is a basic pairing check, not encryption. Use only on a trusted LAN. Do not expose the port to the public internet.
- One peer is accepted per server instance. Audio playback, reconnection, discovery, TLS, and foreground-service operation are future work.

## How to test
1. Install the same build on two Android phones.
2. Connect both phones to the same trusted Wi-Fi network.
3. On phone A, open **Conectividade Universal**, enter a shared code (4–32 characters), choose a port (default 45872), and start the server.
4. Note the local IPv4 address shown by the app.
5. On phone B, enter that IP, the same code and port, then connect.
6. Use **Enviar teste de metadados FM / RDS** to verify that the receiving phone displays the sample metadata.

Android may isolate Wi-Fi clients depending on router settings. Disable guest/client isolation for this local test.
