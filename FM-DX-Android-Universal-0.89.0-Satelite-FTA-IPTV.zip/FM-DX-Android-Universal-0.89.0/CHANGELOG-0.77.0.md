# FM-DX Android Universal 0.77.0 — Reassemblagem PSI/SI

## Implementado
- Novo `PsiSectionAssembler`, associado a um PID, para reconstituir seções PSI/SI a partir de pacotes MPEG-TS de 188 bytes.
- Tratamento do campo de adaptação, payload, PUSI e `pointer_field`.
- Suporte a seções fragmentadas entre pacotes e a múltiplas seções em um mesmo payload.
- Descarte de dados incompletos quando há salto no contador de continuidade, erro de transporte, scrambling ou pacote inválido.
- Limite de tamanho de seção para evitar acumulação ilimitada de dados malformados.
- Testes Kotlin para fragmentação, filtragem de PID e perda de continuidade.

## Relação com a TV ISDB-T
Esta etapa prepara a leitura de tabelas PAT/PMT depois que um backend compatível entregar MPEG-TS. Não carrega firmware, não controla o IT9175, não faz sintonia, não descobre canais por RF e não prova que um endpoint USB específico entregue TS. O parser de seções também não valida CRC MPEG-2; essa validação deverá ser adicionada antes de confiar em tabelas recebidas de hardware real.

## Validação
- Testes Node.js do repositório: executados nesta versão.
- Compilação isolada dos arquivos Kotlin puros `MpegTsAnalyzer.kt` e `PsiSectionAssembler.kt`: executada com `kotlinc`.
- Testes JUnit Android e build APK: não executados neste ambiente.
- Teste com dongle/antena ISDB-T: não realizado.
