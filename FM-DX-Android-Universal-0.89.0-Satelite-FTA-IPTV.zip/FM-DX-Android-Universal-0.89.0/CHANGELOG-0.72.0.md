# 0.72.0 — Catálogo inicial de chipsets de TV USB

- Adicionado catálogo local conservador de VID/PID para famílias Realtek RTL2832U/RTL2832 associadas a dongles DVB-T.
- Diagnóstico USB passa a mostrar correspondência de chipset, família de tuner, padrão associado, confiança e estado do driver.
- VID/PID desconhecidos permanecem como não catalogados; nenhuma inferência automática de padrão ou driver.
- Documentadas as limitações: a placa pode combinar tuner RF diferente, revisão/firmware próprio e não há driver Android universal incluído.
- Mantida a distinção entre DVB-T e ISDB-T/SBTVD brasileiro: reconhecer RTL2832 não significa compatibilidade com TV digital brasileira.
