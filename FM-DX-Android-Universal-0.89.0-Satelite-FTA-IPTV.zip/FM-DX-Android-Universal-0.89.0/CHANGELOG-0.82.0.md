# FM-DX Android Universal 0.82.0 — Grade visual de programação EPG

- Adicionado modelo de grade EPG organizado por emissora/serviço, com eventos em ordem cronológica.
- Conversão de horários UTC do SI para o fuso local selecionado (por padrão, o fuso do aparelho).
- Exibição formatada de horário, duração, título e sinopse, com tratamento explícito de dados ausentes.
- Adicionada tela "Guia de Programação EPG" à navegação principal.
- A tela informa claramente quando ainda não há dados SI reais; não cria canais ou programas fictícios.
- Adicionados testes unitários para agrupamento, ordenação, conversão de horário e grade vazia.

## Limitações

A grade está preparada para receber snapshots do parser SI, mas a integração de captura contínua das tabelas SI com um driver ISDB-T real ainda depende de um backend de sintonizador/demodulador compatível. Não há garantia de recepção sem esse hardware e driver. A compilação integral do APK e testes físicos não foram realizados nesta etapa.
