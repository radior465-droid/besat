# FM-DX Android Universal 0.68.0 — Biblioteca conectada ao áudio nativo

## Novidades
- Integra a biblioteca web de rádios ao serviço Android nativo introduzido na 0.67.0.
- Adiciona a ação **Áudio nativo em segundo plano** nos cartões de estações de rádio compatíveis.
- Permite enviar a estação selecionada na central de reprodução ou um item da fila diretamente ao serviço nativo.
- Cria uma ponte JavaScript/Android mínima com comandos de iniciar, pausar, retomar e parar; a notificação continua oferecendo controles sem precisar manter a página aberta.
- Valida novamente URL, protocolo, host e ausência de credenciais no lado Android e restringe o serviço a áudio direto.
- Adiciona testes unitários para as regras de elegibilidade de mídia nativa.

## Limitações e segurança
- A ponte só aceita HTTP/HTTPS e não contorna DRM, autenticação, restrições de acesso ou políticas de operadoras.
- O player nativo usa `MediaPlayer`; HLS, MPEG-DASH, MPEG-TS, M3U/M3U8 e vídeo são excluídos. Formatos diretos dependem do codec, servidor e Android do aparelho.
- A ponte JavaScript fica disponível na WebView do aplicativo; seus métodos são limitados a reprodução de áudio validada e não expõem acesso genérico a arquivos ou comandos do sistema.
- A reprodução do player web e a reprodução nativa são sessões independentes. Enviar ao serviço nativo inicia uma nova sessão de áudio.
- O Android e fabricantes podem interromper serviços por permissões, economia de bateria ou políticas de segundo plano.
- Não foi possível compilar APK nem testar em hardware físico neste ambiente.
