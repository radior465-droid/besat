# FM-DX Android Universal 0.51.0 — TV Digital USB

## Evolução de TV
- Mantido o inventário USB OTG existente e ampliado com evidências das classes das interfaces USB.
- Novo modelo de compatibilidade para ISDB-T/SBTVD (preferência regional brasileira), DVB-T, DVB-T2, ATSC, ATSC 3.0 e DTMB.
- Relatório agora diferencia dispositivo USB comum de possível dispositivo de vídeo/tuner e mostra VID/PID, interfaces e permissão Android.
- Adicionados testes unitários para preferência ISDB-T no Brasil e classificação conservadora de evidências USB.

## Limites técnicos
- Esta versão detecta e classifica indícios; não contém ainda driver universal, demodulador, captura MPEG-TS nem reprodução de TV ao vivo via dongle.
- Compatibilidade real depende do chipset do dongle (VID/PID), driver/kernel ou biblioteca userspace, acesso USB concedido pelo Android e padrão de transmissão local.
- Para o Brasil, ISDB-T/SBTVD é o alvo prioritário. Nem todo dongle DVB-T/T2 funciona com ISDB-T.

## Validação
- Testes unitários adicionados ao projeto. Executar `./gradlew test` e `./gradlew assembleDebug` em ambiente Android com JDK 17 e SDK 35.
