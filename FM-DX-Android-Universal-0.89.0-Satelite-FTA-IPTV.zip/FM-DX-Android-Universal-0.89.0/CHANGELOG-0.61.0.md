# FM-DX Android Universal 0.61.0 — Inteligência de Compatibilidade

- Adicionada orientação de compatibilidade para MP3, AAC, OGG, Opus, HLS, MPEG-DASH e MPEG-TS.
- A biblioteca de canais agora oferece o botão **Ver compatibilidade**.
- A interface consulta a indicação de suporte do navegador (`canPlayType`) e detecta a disponibilidade de HLS.js/DASH.js.
- Incluídas recomendações de mecanismo de reprodução e avisos sobre codecs, CORS, autenticação e limitações do navegador.
- Adicionado módulo testável `server/compatibility.js`.
- Android atualizado para versionCode 38 / versionName 0.61.0.

A avaliação é heurística e não garante reprodução. Não houve teste em hardware físico nem compilação de APK nesta entrega.
