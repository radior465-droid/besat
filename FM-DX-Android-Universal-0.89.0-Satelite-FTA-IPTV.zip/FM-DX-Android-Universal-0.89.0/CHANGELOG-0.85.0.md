# FM-DX Android Universal 0.85.0 — Catálogo público SDR

- Adiciona catálogo de diretórios públicos: ReceiverBook, diretório e mapa KiwiSDR, WebSDR.org, RX-TX.info, mapa comunitário SDR e Web-888.
- Inclui descrições sobre tecnologias e cobertura, deixando claro que as faixas variam conforme o receptor remoto.
- Links externos abrem em nova aba com `noopener noreferrer`.
- Não cadastra URLs de receptores individuais sem verificação, não declara disponibilidade em tempo real e não realiza varredura global da Internet.
- Mantém o analisador manual de URL SDR introduzido na versão 0.84.0.

## Fontes consultadas
- SWISS-SDR — coleção de diretórios mundiais: https://swiss-sdr.ch/en/links
- AetherSDR Docs — navegação de receptores KiwiSDR públicos: https://docs.aethersdr.com/kiwisdr-and-web-888
- SDR Maps — mapa comunitário de plataformas: https://map-sdr.p00lack.cc/

## Verificação
- Conferência estrutural do HTML/EJS e presença dos sete links do catálogo.
- Não foi compilado APK nesta etapa.
