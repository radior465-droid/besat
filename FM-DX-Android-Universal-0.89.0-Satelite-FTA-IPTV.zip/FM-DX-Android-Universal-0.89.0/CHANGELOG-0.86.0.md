# FM-DX Android Universal 0.86.0 — Atualização do catálogo SDR

- Move os sete diretórios SDR públicos para um catálogo estruturado no servidor.
- Adiciona endpoint autenticado `/api/internet-media/sdr-directory-catalog` para fornecer o índice.
- A interface carrega o catálogo ao abrir, permite atualização manual e atualiza o índice a cada 15 minutos.
- Exibe plataformas e faixas indicativas por diretório, sem afirmar que todos os receptores estejam ativos.
- Mantém links externos em HTTPS com `noopener noreferrer`.
- A atualização automática renova o índice local do aplicativo; não rastreia a internet, não consulta disponibilidade individual e não coleta dados dos diretórios terceiros.

## Verificação
- 3 testes focados do catálogo SDR aprovados.
- Verificação sintática dos arquivos JavaScript do servidor e da interface aprovada.
- APK não compilado nesta etapa.
