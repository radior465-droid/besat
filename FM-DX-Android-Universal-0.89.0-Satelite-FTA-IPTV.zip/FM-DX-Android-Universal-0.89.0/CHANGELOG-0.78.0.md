# FM-DX Android Universal 0.78.0 — Descoberta de serviços PAT/PMT

## Implementado
- `MpegPsiCrc32`: validação do CRC-32 MPEG-2 em seções PSI completas (polinômio `0x04C11DB7`, inicial `0xFFFFFFFF`).
- `TvServiceDiscovery`: pipeline incremental que recebe pacotes TS de 188 bytes, monta PAT no PID 0, descobre PIDs PMT e monta as respectivas PMTs.
- Rejeição de seções PSI com CRC inválido antes de atualizar o catálogo.
- Catálogo de serviços com número de programa, PID PMT, PID PCR, PIDs de vídeo, áudio e demais streams.
- Classificação inicial por `stream_type` MPEG-2/AVC/HEVC e tipos comuns de áudio. É uma classificação de fluxo, não uma garantia de codec/decodificação ou identificação de canal virtual.
- Atualização do catálogo quando a PAT muda e limpeza de estado ao reiniciar a descoberta.
- Testes Kotlin para CRC correto/incorreto, associação PAT→PMT e rejeição de PAT corrompida.

## Limitações importantes
- O scanner trabalha sobre MPEG-TS já entregue ao aplicativo. Não implementa firmware, comandos do IT9175, sintonia RF, demultiplexação por hardware, decodificação de áudio/vídeo ou reprodução.
- Não interpreta ainda tabelas SI específicas para nome da emissora, número lógico de canal, EPG ou regionalização brasileira.
- A classificação de `stream_type` é heurística; descritores privados e variações de emissoras podem exigir análise adicional.

## Validação
- Fontes Kotlin puras de análise TS/PSI compiladas isoladamente com `kotlinc`.
- Três testes de fumaça executados: CRC válido/inválido, descoberta PAT→PMT e rejeição de CRC corrompido.
- Testes Node.js do projeto executados separadamente.
- Build APK, JUnit Android e teste com dongle/antena não executados neste ambiente.
