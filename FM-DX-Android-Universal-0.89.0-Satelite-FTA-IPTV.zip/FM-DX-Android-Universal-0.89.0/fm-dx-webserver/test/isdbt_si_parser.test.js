const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const file = path.join(__dirname, '../../android/app/src/main/java/br/com/fmdx/android/tv/IsdbtSiParser.kt');
const src = fs.readFileSync(file, 'utf8');

test('parser SI reconhece SDT real e SDT other com CRC validado', () => {
  assert.match(src, /0x42, 0x46 -> parseSdt/);
  assert.match(src, /MpegPsiCrc32\.isValidSection\(section\)/);
  assert.match(src, /tag == 0x48/);
});

test('parser EIT extrai evento, horário MJD/BCD e descritor short_event', () => {
  assert.match(src, /in 0x4E\.\.0x6F -> parseEit/);
  assert.match(src, /tag == 0x4D/);
  assert.match(src, /decodeMjdTime/);
  assert.match(src, /decodeDuration/);
});

test('parser SI usa o decodificador ARIB STD-B24 e não inventa LCN', () => {
  assert.match(src, /AribB24Decoder/);
  assert.match(src, /textDecoder\.decode/);
  assert.doesNotMatch(src, /logicalChannelNumber|lcnValue/);
});

test('decodificador ARIB implementa designação e invocação dos conjuntos comuns', () => {
  const decoder = fs.readFileSync(path.join(__dirname, '../../android/app/src/main/java/br/com/fmdx/android/tv/AribB24Decoder.kt'), 'utf8');
  assert.match(decoder, /SetKind\.KANJI/);
  assert.match(decoder, /SetKind\.HIRAGANA/);
  assert.match(decoder, /SetKind\.KATAKANA/);
  assert.match(decoder, /0x0e -> \{ gl = 1/);
  assert.match(decoder, /0x19 -> \{ singleShift = 2/);
});


test('decodificador ARIB protege limites e preserva tratamento de GR/SS2', () => {
  const decoder = fs.readFileSync(path.join(__dirname, '../../android/app/src/main/java/br/com/fmdx/android/tv/AribB24Decoder.kt'), 'utf8');
  assert.match(decoder, /length > data\.size - offset/);
  assert.match(decoder, /0x19 -> \{ singleShift = 2/);
  assert.match(decoder, /val isGr = raw >= 0xa1/);
});
