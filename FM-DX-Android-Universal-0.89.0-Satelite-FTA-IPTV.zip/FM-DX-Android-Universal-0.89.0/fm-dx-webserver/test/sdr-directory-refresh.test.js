const test = require('node:test');
const assert = require('node:assert/strict');
const { getSdrDirectoryCatalog } = require('../server/sdr_directory_catalog');

test('catálogo SDR pode ser atualizado e informa claramente que não verifica receptores', () => {
  const catalog = getSdrDirectoryCatalog();
  assert.equal(catalog.version, 3);
  assert.equal(catalog.refreshIntervalSeconds, 900);
  assert.ok(Number.isFinite(Date.parse(catalog.updatedAt)));
  assert.ok(catalog.sources.length >= 11);
  assert.ok(catalog.discoverySearches.length >= 6);
  assert.ok(catalog.discoverySearches.some(item => item.id === 'vhf-uhf-search'));
  assert.ok(catalog.discoverySearches.some(item => item.id === 'shortwave-search'));
  assert.ok(catalog.sources.some(source => source.platforms.includes('KiwiSDR')));
  assert.match(catalog.note, /não rastreia toda a internet/i);
  assert.ok(catalog.sources.some(source => source.id === 'sdr-global-atlas'));
  assert.ok(catalog.sources.some(source => source.id === 'kc4mcq-live-sdr'));
});

test('todas as URLs do catálogo usam HTTPS e não incluem credenciais', () => {
  for (const source of getSdrDirectoryCatalog().sources) {
    const url = new URL(source.url);
    assert.equal(url.protocol, 'https:');
    assert.equal(url.username, '');
    assert.equal(url.password, '');
  }
});
