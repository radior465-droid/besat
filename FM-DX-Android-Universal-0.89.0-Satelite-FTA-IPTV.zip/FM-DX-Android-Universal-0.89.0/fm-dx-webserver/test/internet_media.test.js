'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { classify, parsePlaylist, isPrivateAddress, classifySdrServer } = require('../server/internet_media');

test('detecta formatos comuns de rádio', () => {
  assert.equal(classify('audio/mpeg', 'https://radio.example/live').format, 'MP3');
  assert.equal(classify('audio/aac', 'https://radio.example/live').media, 'radio');
  assert.equal(classify('audio/ogg', 'https://radio.example/live.ogg').format, 'OGG');
});

test('detecta HLS, DASH e MPEG-TS', () => {
  assert.equal(classify('application/vnd.apple.mpegurl', 'https://tv.example/live.m3u8').format, 'HLS');
  assert.equal(classify('application/dash+xml', 'https://tv.example/live.mpd').format, 'MPEG-DASH');
  assert.equal(classify('video/mp2t', 'https://tv.example/chunk.ts').format, 'MPEG-TS');
});

test('extrai URLs de uma playlist sem comentários', () => {
  const items = parsePlaylist('#EXTM3U\n#EXTINF:-1,Canal A\nhttps://example.org/a.m3u8\n');
  assert.deepEqual(items, ['https://example.org/a.m3u8']);
});

test('bloqueia endereços privados e permite IP público', () => {
  assert.equal(isPrivateAddress('127.0.0.1'), true);
  assert.equal(isPrivateAddress('192.168.1.2'), true);
  assert.equal(isPrivateAddress('8.8.8.8'), false);
});


test('extrai metadados EXTINF e resolve URLs relativas', () => {
  const { parsePlaylistEntries } = require('../server/internet_media');
  const entries = parsePlaylistEntries('#EXTM3U\n#EXTINF:-1 tvg-id="news.br" tvg-name="Notícias" tvg-logo="https://img.example/logo.png" group-title="TV",Notícias ao vivo\n/live/news.m3u8\n', 'https://lista.example/iptv/list.m3u');
  assert.equal(entries.length, 1);
  assert.equal(entries[0].title, 'Notícias');
  assert.equal(entries[0].tvgId, 'news.br');
  assert.equal(entries[0].group, 'TV');
  assert.equal(entries[0].url, 'https://lista.example/live/news.m3u8');
  assert.equal(entries[0].media, 'tv');
  assert.equal(entries[0].ftaStatus, 'não informado');
  const open = parsePlaylistEntries('#EXTM3U\n#EXTINF:-1 group-title=\"FTA - TV Aberta\",Canal Livre\nhttps://stream.example/live.m3u8');
  assert.equal(open[0].ftaStatus, 'indicado como FTA');
});

test('classifica formatos e pistas de rádio/TV em entradas', () => {
  const { inferFormatFromUrl, inferMediaFromEntry } = require('../server/internet_media');
  assert.equal(inferFormatFromUrl('https://radio.example/live.mp3'), 'MP3');
  assert.equal(inferMediaFromEntry('https://host.example/stream', 'Rádios FM', 'Rádio Central'), 'radio');
  assert.equal(inferMediaFromEntry('https://host.example/live', 'TV Aberta', 'Canal 7'), 'tv');
});


test('não confunde playlist HLS de segmentos com lista de canais', async () => {
  const { isHlsSegmentPlaylist } = require('../server/internet_media');
  assert.equal(isHlsSegmentPlaylist('#EXTM3U\n#EXT-X-TARGETDURATION:6\n#EXTINF:6.0,\nsegment001.ts\n'), true);
  assert.equal(isHlsSegmentPlaylist('#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=1200000\nvariant.m3u8\n'), false);
});

test('limita a extração de playlist a 100 entradas', () => {
  const { parsePlaylistEntries } = require('../server/internet_media');
  const body = '#EXTM3U\n' + Array.from({length: 130}, (_, i) => `https://streams.example/${i}.mp3`).join('\n');
  assert.equal(parsePlaylistEntries(body).length, 100);
});


test('unifica canais por tvg-id e remove duplicados entre playlists', () => {
  const { buildUnifiedCatalogue } = require('../server/internet_media');
  const result = buildUnifiedCatalogue([
    { url: 'https://lista.example/a.m3u', entries: [{ url: 'https://stream.example/a', title: 'Canal A', tvgId: 'canal.a', logo: '', availability: 'não confirmado' }] },
    { url: 'https://lista.example/b.m3u', entries: [{ url: 'https://outro.example/a', title: 'Canal A HD', tvgId: 'CANAL.A', logo: 'https://img.example/a.png', availability: 'ativo' }, { url: 'https://stream.example/b', title: 'Canal B', tvgId: '', availability: 'ativo' }] }
  ]);
  assert.equal(result.entries.length, 2);
  assert.equal(result.duplicates, 1);
  assert.equal(result.entries.find(x => x.tvgId.toLowerCase() === 'canal.a').availability, 'ativo');
  assert.equal(result.entries.find(x => x.tvgId.toLowerCase() === 'canal.a').sources.length, 2);
});

test('unifica entradas sem tvg-id por URL sem fragmento', () => {
  const { buildUnifiedCatalogue } = require('../server/internet_media');
  const result = buildUnifiedCatalogue([{ url: 'a', entries: [{ url: 'https://stream.example/live#one', title: 'Rádio', tvgId: '' }] }, { url: 'b', entries: [{ url: 'https://stream.example/live#two', title: 'Rádio', tvgId: '' }] }]);
  assert.equal(result.entries.length, 1);
  assert.equal(result.duplicates, 1);
});

test('recheck rejeita lista vazia ou acima do limite sem consultar a rede', async () => {
  const { recheckEntries } = require('../server/internet_media');
  await assert.rejects(() => recheckEntries([]), /1 a 100/);
  await assert.rejects(() => recheckEntries(Array.from({ length: 101 }, (_, i) => ({ url: `https://x.example/${i}` }))), /1 a 100/);
  await assert.rejects(() => recheckEntries([{ title: 'Sem URL' }]), /URL válida/);
});

test('gera orientação de compatibilidade para MP3, HLS, DASH e MPEG-TS', () => {
  const { getCompatibilityProfile } = require('../server/compatibility');
  assert.equal(getCompatibilityProfile('MP3', 'radio').engine, 'HTML5 Audio');
  assert.match(getCompatibilityProfile('HLS', 'tv').engine, /HLS/);
  assert.match(getCompatibilityProfile('MPEG-DASH', 'tv').engine, /DASH.js/);
  assert.match(getCompatibilityProfile('MPEG-TS', 'tv').recommendation, /MPEG-TS/);
});

test('não promete compatibilidade para formatos desconhecidos', () => {
  const { getCompatibilityProfile } = require('../server/compatibility');
  const profile = getCompatibilityProfile('formato-exótico', 'tv');
  assert.equal(profile.support, 'não confirmado');
  assert.match(profile.caveat, /Não garante reprodução/);
});

test('diagnóstico identifica autenticação sem sugerir contorno', () => {
  const { diagnoseInspection } = require('../server/diagnostics');
  const result = diagnoseInspection({ status: 403, format: 'HLS', media: 'tv' });
  assert.equal(result.state, 'autenticacao');
  assert.match(result.action, /não tenta contornar/i);
});

test('diagnóstico separa redirecionamento, ausência e limite do servidor', () => {
  const { diagnoseInspection } = require('../server/diagnostics');
  assert.equal(diagnoseInspection({ status: 302, media: 'redirecionamento' }).state, 'redirecionamento');
  assert.equal(diagnoseInspection({ status: 404 }).state, 'endereco-nao-encontrado');
  assert.equal(diagnoseInspection({ status: 429 }).state, 'limite-de-acesso');
});

test('diagnóstico alerta sobre MIME e CORS não confirmado', () => {
  const { diagnoseInspection } = require('../server/diagnostics');
  const result = diagnoseInspection({ status: 200, format: 'MP3', media: 'radio', contentType: 'text/html' }, { cors: 'unknown', canPlayType: '' });
  assert.ok(result.issues.some(x => /MIME/.test(x)));
  assert.ok(result.issues.some(x => /CORS/.test(x)));
  assert.ok(result.issues.some(x => /suporte/.test(x)));
});

test('diagnóstico não confunde HTTP 200 com reprodução garantida', () => {
  const { diagnoseInspection } = require('../server/diagnostics');
  const result = diagnoseInspection({ status: 200, format: 'HLS', media: 'tv', playlist: true });
  assert.equal(result.state, 'servidor-respondeu');
  assert.ok(result.limitations.some(x => /não garante reprodução/i.test(x)));
  assert.ok(result.issues.some(x => /playlist/i.test(x)));
});

test('diagnóstico identifica timeout sem criar endereço alternativo', () => {
  const { diagnoseInspection } = require('../server/diagnostics');
  const result = diagnoseInspection({ error: 'timeout' });
  assert.equal(result.state, 'tempo-esgotado');
  assert.equal(result.httpStatus, null);
  assert.equal(result.format, 'desconhecido');
});

test('fila de reprodução valida URLs, limita itens e avança em ordem', () => {
  const { sanitizeQueue, takeNext } = require('../server/playback_queue');
  const entries = [{ url: 'https://radio.example/a' }, { url: 'javascript:alert(1)' }, { url: 'https://radio.example/b' }];
  assert.equal(sanitizeQueue(entries).length, 2);
  const result = takeNext(entries);
  assert.equal(result.next.url, 'https://radio.example/a');
  assert.equal(result.remaining.length, 1);
  assert.equal(result.remaining[0].url, 'https://radio.example/b');
});

test('histórico encontra canal anterior sem repetir o atual', () => {
  const { findPrevious } = require('../server/playback_queue');
  const history = [{ url: 'https://radio.example/current' }, { url: 'https://radio.example/previous' }];
  assert.equal(findPrevious(history, 'https://radio.example/current').url, 'https://radio.example/previous');
  assert.equal(findPrevious([{ url: 'javascript:bad' }], 'x'), null);
});


test('reconhece interfaces SDR remotas por URL e conteúdo', () => {
  const kiwi = classifySdrServer(new URL('https://radio.example/'), '<title>KiwiSDR receiver</title>');
  assert.equal(kiwi.platform, 'KiwiSDR');
  assert.equal(kiwi.supported, true);
  const openwebrx = classifySdrServer(new URL('https://sdr.example/'), '<html>OpenWebRX receiver</html>');
  assert.equal(openwebrx.platform, 'OpenWebRX');
  const websdr = classifySdrServer(new URL('https://websdr.example/'), '<title>WebSDR</title>');
  assert.equal(websdr.platform, 'WebSDR');
});

test('não inventa faixas quando a página SDR não as anuncia', () => {
  const result = classifySdrServer(new URL('https://sdr.example/'), '<html>OpenWebRX</html>');
  assert.deepEqual(result.ranges, []);
});
