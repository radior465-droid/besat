'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const page = fs.readFileSync(path.join(__dirname, '../web/internet-media.ejs'), 'utf8');

test('interface inclui controle de volume limitado de 0 a 100', () => {
  assert.match(page, /id="centralVolume" type="range" min="0" max="100"/);
  assert.match(page, /el\.volume=value\/100/);
});

test('temporizador oferece durações e interrompe a reprodução', () => {
  for (const minutes of ['15','30','45','60','90','120']) assert.match(page, new RegExp(`<option value="${minutes}">`));
  assert.match(page, /setTimeout\(\(\)=>\{stopCentralPlayback\(\)/);
});

test('modo contínuo é salvo e pode repetir o canal atual', () => {
  assert.match(page, /fmdx-continuous-playback/);
  assert.match(page, /else if\(continuousPlayback&&currentPlayback\)/);
  assert.match(page, /replay\.play\(\)/);
});

test('layout tem ajustes específicos para telas móveis', () => {
  assert.match(page, /@media\(max-width:600px\)/);
  assert.match(page, /min-height:44px/);
});
