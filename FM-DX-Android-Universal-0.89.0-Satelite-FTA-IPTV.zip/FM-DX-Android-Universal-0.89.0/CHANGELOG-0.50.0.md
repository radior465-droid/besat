# FM-DX Android Universal 0.50.0

## Detector observacional de nós e caminhos de rádio
- Adicionado `RadioNodeEvidenceScanner`, com lista explícita de caminhos conhecidos em `/dev`, `/sys`, `/vendor` e `/system`.
- O relatório distingue caminho presente/ausente, arquivo/diretório e permissões de leitura/escrita observáveis pelo próprio aplicativo.
- O `FmDriverProbe` incorpora o resumo e as evidências encontradas.
- A inspeção é somente de metadados: não lê nós de dispositivo, não faz varredura recursiva, não instala drivers, não usa root e não tenta controlar tuner.

## Interpretação e limites
- Um caminho presente ou legível é apenas indício; não comprova que exista tuner FM, que o driver corresponda ao hardware, nem que sintonia/áudio funcionem.
- Caminhos ausentes podem resultar de diferenças de kernel, SELinux, namespaces ou permissões do Android.
- Recursos proprietários e HALs podem não ser visíveis para aplicativos comuns.

## Validação
- Inspeção estática do código e estrutura do pacote.
- A compilação Android e os testes JUnit devem ser executados no Android Studio/Gradle com JDK 17 e SDK 35.
