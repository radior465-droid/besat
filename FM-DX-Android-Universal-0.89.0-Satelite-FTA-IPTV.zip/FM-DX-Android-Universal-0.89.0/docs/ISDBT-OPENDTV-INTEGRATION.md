# Integração ISDB-T: avaliação do OpenDTV (0.76.0)

## Descoberta

O projeto público [jpdcs/OpenDTV](https://github.com/jpdcs/OpenDTV) declara ser um player Android ISDB-T que comunica diretamente com dongles via USB Host/OTG. Seu README lista o Mygica PadTV PT275 e o ITE/Afatech IT9175 com USB ID `048D:275A` como suportados e confirmados em hardware. Também lista o IT9308 (`048D:9308`), mas ressalva que precisa de testes adicionais.

O upstream descreve funcionalidades que podem orientar uma futura integração: sintonia manual/automática, leitura de MPEG-TS, análise de tabelas PSI/SI, EPG e reprodução Media3. Isso é evidência do projeto upstream, não uma validação do FM-DX.

## O que esta versão implementa

- Catálogo tipado de perfis upstream para IT9175/PT275 e IT9308.
- Busca exata por VID/PID para orientar a seleção do backend.
- Estados de evidência distintos: confirmação pública em hardware versus suporte que ainda precisa de testes.
- Documentação da arquitetura de integração e das dependências de validação.

## O que NÃO foi copiado ou ativado

Nenhum código-fonte do OpenDTV foi incorporado nesta versão e nenhum comando USB, firmware, rotina de sintonia ou endpoint MPEG-TS foi presumido. A seleção do perfil não abre o dispositivo nem inicia recepção. O adaptador IT9175 existente continua em modo de diagnóstico seguro.

## Próximas etapas antes de integrar o driver

1. Revisar os arquivos upstream relevantes (`It9175Tuner`, fonte USB e pipeline TS) e registrar commit/hash exato.
2. Comparar APIs Android, minSdk, Media3 e dependências com este projeto.
3. Preservar avisos de copyright e incluir o texto MIT do upstream se código MIT for incorporado.
4. Avaliar separadamente dependências GPL-3.0 (o README upstream menciona NextLib para fallback FFmpeg); não misturar ou redistribuir binários sem revisão de compatibilidade de licenças.
5. Portar em módulo isolado, com testes de protocolo usando capturas/dados simulados.
6. Só declarar suporte funcional após build Android e ensaio em dongle real, antena e cobertura ISDB-T.

## Limitações práticas

- Requer Android com USB Host/OTG, adaptador OTG adequado, dongle compatível, antena e sinal ISDB-T.
- Um VID/PID pode identificar uma família, não necessariamente a revisão exata da placa ou cristal.
- O suporte upstream não garante funcionamento no Samsung SM-A145M nem em todo aparelho Android.
- A TV aberta recebida deve ser conteúdo livre; não há implementação de quebra de criptografia/DRM.

## Fonte

- OpenDTV (README e licença): https://github.com/jpdcs/OpenDTV
