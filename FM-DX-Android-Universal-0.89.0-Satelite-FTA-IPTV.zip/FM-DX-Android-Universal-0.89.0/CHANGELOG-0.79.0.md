# FM-DX Android Universal 0.79.0 — SI: emissoras e programação

## Implementado
- `IsdbtSiParser` consome seções SI completas e valida CRC MPEG-2 antes de interpretar conteúdo.
- SDT atual (table_id `0x42`) e SDT other (`0x46`): service_id, service_type e descritor `service_descriptor` (`0x48`) para provedor/nome.
- EIT (`0x4E` a `0x6F`): service_id, event_id, início em MJD/BCD, duração BCD e `short_event_descriptor` (`0x4D`) para título/resumo.
- Catálogo ordenado de emissoras e eventos, com reset e contador de seções rejeitadas.
- Versão Android atualizada para 0.79.0 (versionCode 56).

## Limitações
- A decodificação de texto é best-effort ISO-8859-1. Texto japonês/brasileiro codificado segundo ARIB STD-B24 precisa de um decodificador próprio e não é alegado como suportado.
- Não interpreta número lógico de canal (LCN), tabelas específicas de emissoras ou extensões privadas ainda não documentadas.
- O parser recebe seções SI já montadas; não faz sintonia RF, inicialização do IT9175, demultiplexação USB nem reprodução.
- Horários EIT são apresentados como UTC a partir do MJD/BCD; conversão de fuso/regra local deve ser feita em camada posterior.

## Validação
- Testes Node.js verificam os contratos de parsing SDT/EIT, CRC e limites declarados.
- Build APK, testes JUnit Android e validação com dongle/antena não executados neste ambiente.
