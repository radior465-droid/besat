# FM-DX Android Universal 0.58.0

## Biblioteca Universal de Rádio e TV

- Importação de até 10 playlists M3U/M3U8 em uma operação.
- Varredura sequencial de cada playlist para manter a carga de rede limitada.
- Biblioteca unificada com deduplicação por `tvg-id`; sem ID, usa URL sem fragmento.
- Consolidação de fontes de origem e preferência por logo/disponibilidade ativa quando existem duplicatas.
- Pesquisa por nome, grupo, ID ou URL e filtro por rádio/TV.
- Persistência local da biblioteca e favoritos no navegador.
- Resumo de playlists processadas, falhas, canais únicos e duplicatas removidas.

## Segurança e limites
- Apenas URLs HTTP/HTTPS fornecidas explicitamente pelo administrador autenticado.
- Até 10 playlists por importação e até 100 entradas por playlist.
- Mantém bloqueio de IPs locais/privados, leitura limitada, timeout e redirecionamentos manuais.
- Não intercepta tráfego de outros aplicativos nem contorna autenticação, DRM ou restrições de acesso.

## Testes
- Testes automatizados para deduplicação por ID e URL.
- Verificações de sintaxe Node.js e integridade do arquivo ZIP realizadas na preparação da fonte.
