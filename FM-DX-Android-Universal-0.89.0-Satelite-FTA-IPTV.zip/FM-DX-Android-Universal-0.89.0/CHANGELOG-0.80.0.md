# Versão 0.80.0 — Decodificação ARIB STD-B24 para SI/EPG

- Adicionado `AribB24Decoder` para os conjuntos comuns de alfanumérico, hiragana, katakana e Kanji via mapeamento EUC-JP.
- Implementados controles de designação ISO-2022 para G0–G3, locking shifts GL/GR e single shifts SS2/SS3.
- Parser SDT/EIT agora usa o decodificador ARIB em nomes de serviços, provedores, títulos e resumos.
- Incluídos testes para alfanumérico, hiragana, katakana e shifts.

## Limites conhecidos

Esta é uma implementação parcial, não um decodificador integral da ARIB STD-B24. DRCS, mosaicos, macros, conjuntos proporcionais, símbolos adicionais, controles de apresentação/legenda e todas as extensões de Kanji não estão implementados. O mapeamento Kanji depende do charset `EUC-JP` disponível no runtime Android. Dados malformados podem produzir caracteres de substituição ou texto incompleto. Nenhuma sintonia RF, driver IT9175 ou recepção física foi habilitada por esta versão.
