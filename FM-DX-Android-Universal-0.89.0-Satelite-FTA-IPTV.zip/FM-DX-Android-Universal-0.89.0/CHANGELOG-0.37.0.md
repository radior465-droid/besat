# FM-DX Android Universal 0.37.0 — Hardware Test Lab

## Novidades
- Expansão do Laboratório de Hardware com inventário observacional de identidade do aparelho, família de fabricante, plataforma/SoC e assinatura do hardware.
- Enumeração de recursos de sistema com nomes relacionados a FM, rádio ou tuner.
- Enumeração de dispositivos de áudio expostos pelo Android.
- Verificação da declaração de suporte a USB Host e listagem de periféricos USB conectados (VID/PID/interfaces).
- Relatório com data/hora e interpretação conservadora dos resultados.
- Atualização do versionName para 0.37.0 e versionCode para 22.

## Limites
- Nenhum teste tenta sintonizar ou controlar o receptor FM.
- Dispositivo de áudio, recurso declarado, marca ou SoC não comprovam tuner FM físico nem acesso ao driver/HAL.
- Frequência de cristal/PLL não é inferida quando não está exposta por interface pública.
- Teste real de sintonia e áudio continua necessário para confirmar compatibilidade por modelo, variante e firmware.
