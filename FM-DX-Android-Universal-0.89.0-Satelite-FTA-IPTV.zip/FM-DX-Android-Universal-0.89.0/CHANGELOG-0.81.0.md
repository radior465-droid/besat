# FM-DX Android Universal 0.81.0

## ARIB STD-B24 — robustez do decodificador
- Proteção contra estouro de inteiro e fatias inválidas na entrada do decodificador.
- Cobertura de testes para seleção GR inicial, single shift SS2, par Kanji truncado e comprimentos inválidos.
- Reutilização da referência de charset EUC-JP para o conjunto JIS X 0201 Katakana.
- Mantém escopo parcial: não implementa DRCS, mosaicos, macros, conjunto completo de símbolos adicionais, controles de apresentação/legendas nem semântica integral de todos os conjuntos ARIB.

## Validação
- Testes automatizados Node.js e testes isolados do decodificador Kotlin.
- APK completo/Gradle e recepção com dongle físico não validados nesta versão.
